locals {
  aks = yamldecode(file("../config/config.yml"))["aks"]
  waf_exclusions = yamldecode(file("../config/appgw_waf_exclusions.yml"))
  # Only Argocd domain logic
  argocd_domain_is_present = try(local.aks.argocd_domain, null) != null ? true : false

  # SSL certificates for Application Gateway (Argocd only)
  appgw_ssl_certificates = local.argocd_domain_is_present ? [
    {
      name                = replace(try(local.aks.argocd_domain, ""), ".", "-")
      key_vault_secret_id = "${module.aks.key_vault.vault_uri}secrets/${replace(try(local.aks.argocd_domain, ""), ".", "-")}"
    }
  ] : []
}

data "azurerm_subscription" "current" {
}

resource "azurerm_resource_group" "aks_resources" {
  name     = "rg-${local.aks.fullname}-003"
  location = local.aks.location

  tags = data.azurerm_subscription.current.tags
}

# Define the Azure DevOps Managed Identity
resource "azurerm_user_assigned_identity" "ado_managed_identity" {
  name                = "ado-${local.aks.fullname}-identity"
  resource_group_name = azurerm_resource_group.aks_resources.name
  location            = azurerm_resource_group.aks_resources.location
}

module "aks" {
  source = "git::ssh://git@ssh.dev.azure.com/v3/MCP-TenneT/cf-workload-modules/terraform-azurerm-wps-kubernetes?ref=v5.1.1"

  fullname  = local.aks.fullname
  shortname = local.aks.shortname
  location  = local.aks.location

  acr_existing_acr_id = local.aks.acr_existing_acr_id
  
  aks_dns_id               = local.aks.aks_dns_id
  aks_number_of_node_pools = local.aks.aks_number_of_node_pools
  aks_system_nodes_subnet_ids  = local.aks.aks_system_nodes_subnet_ids
  aks_system_pods_subnet_ids   = local.aks.aks_system_pods_subnet_ids
  aks_version                  = local.aks.aks_version
  aks_vnet_id                  = local.aks.aks_vnet_id
  aks_workload_subnet_ids      = local.aks.aks_workload_subnet_ids
  aks_workload_pods_subnet_ids = local.aks.aks_workload_pods_subnet_ids
  appgw_subnet_id              = local.aks.appgw_subnet_id
  appgw_private_ip_address     = local.aks.appgw_private_ip_address
  aks_azure_policy_enabled     = local.aks.aks_azure_policy_enabled

  appgw_waf_managed_rules = {
    managed_rule_set = {
      type                 = "OWASP"
      version              = "3.2"
      rule_group_overrides = []
      exclusions           = local.waf_exclusions.appgw_waf_exclusions
    }
  }  

  appgw_waf_policy_settings = {
    mode = "Prevention"
    request_body_enforcement = false
  }
  appgw_ssl_certificates = try(local.appgw_ssl_certificates, [])
  appgw_ssl_policy = {
    policy_type = "CustomV2"
    cipher_suites = [
      "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
      "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
      "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256",
      "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384"
    ]
    min_protocol_version = "TLSv1_2"
  }
  
  monitor_metrics = {
    annotations_allowed = null
    labels_allowed      = null
  }

  private_endpoint_subnet_id = local.aks.private_endpoint_subnet_id

  group_names = {
    AzureKubernetesServiceRBACAdmin        = local.aks.AzureKubernetesServiceRBACAdmin
    AzureKubernetesServiceRBACClusterAdmin = local.aks.AzureKubernetesServiceRBACClusterAdmin
    AzureKubernetesServiceRBACReader       = local.aks.AzureKubernetesServiceRBACReader
    AzureKubernetesServiceRBACWriter       = local.aks.AzureKubernetesServiceRBACWriter
  }

  group_names_kv = {
    Administrator                  = local.aks.Administrator
    Certificates_User              = local.aks.Certificates_User
    Certificates_Officer           = local.aks.Certificates_Officer
    Contributor                    = local.aks.Contributor
    Crypto_Officer                 = local.aks.Crypto_Officer
    Crypto_Service_Encryption_User = local.aks.Crypto_Service_Encryption_User
    Crypto_Service_Release_User    = local.aks.Crypto_Service_Release_User
    Crypto_User                    = local.aks.Crypto_User
    Data_Access_Administrator      = local.aks.Data_Access_Administrator
    Reader                         = local.aks.Reader
    Secrets_Officer                = local.aks.Secrets_Officer
    Secrets_User                   = local.aks.Secrets_User
  }
  pim_enabled = local.aks.pim_enabled

  mandatory_tags = merge(data.azurerm_subscription.current.tags, { UnitCode = "CPS.MSA.24003.001" })
}

data "azurerm_kubernetes_cluster" "aks" {
  depends_on = [
    module.aks
  ]

  name                = "aks-${local.aks.fullname}-001"
  resource_group_name = "rg-${local.aks.fullname}-001"
}

# Assign the RBAC role to the Managed Identity
resource "azurerm_role_assignment" "aks_rbac_cluster_admin" {
  scope                = data.azurerm_kubernetes_cluster.aks.id
  role_definition_name = "Azure Kubernetes Service RBAC Cluster Admin"
  principal_id         = azurerm_user_assigned_identity.ado_managed_identity.principal_id
}