terraform {
  required_version = "~>1.0"
  required_providers {
    azurerm = {
      source                = "hashicorp/azurerm"
      version               = "~>4.0"
      configuration_aliases = [azurerm.acceptance_subscription]
    }
    azapi = {
      source  = "Azure/azapi"
      version = "~>1.0"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~>3.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~>3.0"
    }
    template = {
      source  = "hashicorp/template"
      version = "~>2.0"
    }
    null = {
      source  = "hashicorp/null"
      version = "~>3.0"
    }
    tls = {
      source  = "hashicorp/tls"
      version = "~>4.0"
    }
  }
  backend "azurerm" {}
}

provider "azurerm" {
  alias           = "acceptance_subscription"
  subscription_id = "5bdb1978-288f-494e-8bb1-b32f51e2fad1"
  features {
    resource_group {
      prevent_deletion_if_contains_resources = false
    }
  }
}

provider "azurerm" {
  features {}
}  