#This secret should be created manually before running this module or pipeline
data "azurerm_key_vault_secret" "argocd_pfx_password" {
  count        = local.argocd_domain_is_present ? 1 : 0
  name         = format("%s-pfx-password", replace(local.aks.argocd_domain, ".", "-"))
  key_vault_id = module.aks.key_vault.id
}
resource "azurerm_key_vault_certificate" "argocd_ssl_certificate" {
  count        = local.argocd_domain_is_present ? 1 : 0
  name         = replace(local.aks.argocd_domain, ".", "-")
  key_vault_id = module.aks.key_vault.id
  certificate {
    contents = filebase64("${path.module}/../ssl_certs/${local.aks.argocd_domain}.pfx")
    password = data.azurerm_key_vault_secret.argocd_pfx_password[count.index].value
  }
}
// #This secret should be created manually before running this module or pipeline
// data "azurerm_key_vault_secret" "kubecost_pfx_password" {
//   count        = local.kubecost_domain_is_present ? 1 : 0
//   name         = format("%s-pfx-password", replace(local.aks.kubecost_domain, ".", "-"))
//   key_vault_id = module.aks.key_vault.id
// }
// resource "azurerm_key_vault_certificate" "kubecost_ssl_certificate" {
//   count        = local.kubecost_domain_is_present ? 1 : 0
//   name         = replace(local.aks.kubecost_domain, ".", "-")
//   key_vault_id = module.aks.key_vault.id
//   certificate {
//     contents = filebase64("${path.module}/../ssl_certs/${local.aks.kubecost_domain}.pfx")
//     password = data.azurerm_key_vault_secret.kubecost_pfx_password[count.index].value
//   }
// }