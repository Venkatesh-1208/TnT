resource "azuread_group_role_management_policy" "azurekubernetesservicerbacadmin_group" {
  count    = var.pim_enabled ? 1 : 0
  group_id = azuread_group.azurekubernetesservicerbacadmin_group.id
  role_id  = var.pim_policy.role_id

  eligible_assignment_rules {
    expiration_required = var.pim_policy.eligible_assignment_rules.expiration_required
  }
  activation_rules {
    approval_stage {
      primary_approver {
        object_id = azuread_group.azurekubernetesservicerbacadmin_group.object_id
        type      = var.pim_policy.activation_rules.approval_stage.primary_approver.type
      }
    }
    maximum_duration                   = var.pim_policy.activation_rules.maximum_duration
    require_approval                   = var.pim_policy.activation_rules.require_approval
    require_justification              = var.pim_policy.activation_rules.require_justification
    require_multifactor_authentication = var.pim_policy.activation_rules.require_multifactor_authentication
  }
}

resource "azuread_group_role_management_policy" "azurekubernetesservicerbacclusteradmin_group" {
  count    = var.pim_enabled ? 1 : 0
  group_id = azuread_group.azurekubernetesservicerbacclusteradmin_group.id
  role_id  = var.pim_policy.role_id

  eligible_assignment_rules {
    expiration_required = var.pim_policy.eligible_assignment_rules.expiration_required
  }
  activation_rules {
    approval_stage {
      primary_approver {
        object_id = azuread_group.azurekubernetesservicerbacclusteradmin_group.object_id
        type      = var.pim_policy.activation_rules.approval_stage.primary_approver.type
      }
    }
    maximum_duration                   = var.pim_policy.activation_rules.maximum_duration
    require_approval                   = var.pim_policy.activation_rules.require_approval
    require_justification              = var.pim_policy.activation_rules.require_justification
    require_multifactor_authentication = var.pim_policy.activation_rules.require_multifactor_authentication
  }
}

resource "azuread_group_role_management_policy" "azurekubernetesservicerbacreader_group" {
  count    = var.pim_enabled ? 1 : 0
  group_id = azuread_group.azurekubernetesservicerbacreader_group.id
  role_id  = var.pim_policy.role_id

  eligible_assignment_rules {
    expiration_required = var.pim_policy.eligible_assignment_rules.expiration_required
  }
  activation_rules {
    approval_stage {
      primary_approver {
        object_id = azuread_group.azurekubernetesservicerbacreader_group.object_id
        type      = var.pim_policy.activation_rules.approval_stage.primary_approver.type
      }
    }
    maximum_duration                   = var.pim_policy.activation_rules.maximum_duration
    require_approval                   = var.pim_policy.activation_rules.require_approval
    require_justification              = var.pim_policy.activation_rules.require_justification
    require_multifactor_authentication = var.pim_policy.activation_rules.require_multifactor_authentication
  }
}

resource "azuread_group_role_management_policy" "azurekubernetesservicerbacwriter_group" {
  count    = var.pim_enabled ? 1 : 0
  group_id = azuread_group.azurekubernetesservicerbacwriter_group.id
  role_id  = var.pim_policy.role_id

  eligible_assignment_rules {
    expiration_required = var.pim_policy.eligible_assignment_rules.expiration_required
  }
  activation_rules {
    approval_stage {
      primary_approver {
        object_id = azuread_group.azurekubernetesservicerbacwriter_group.object_id
        type      = var.pim_policy.activation_rules.approval_stage.primary_approver.type
      }
    }
    maximum_duration                   = var.pim_policy.activation_rules.maximum_duration
    require_approval                   = var.pim_policy.activation_rules.require_approval
    require_justification              = var.pim_policy.activation_rules.require_justification
    require_multifactor_authentication = var.pim_policy.activation_rules.require_multifactor_authentication
  }
}

resource "azuread_group_role_management_policy" "keyvault_group" {
  for_each = var.pim_enabled ? local.group_names_map_kv : {}
  group_id = azuread_group.rbac_keyvault_group[each.key].id
  role_id  = var.pim_policy.role_id

  eligible_assignment_rules {
    expiration_required = var.pim_policy.eligible_assignment_rules.expiration_required
  }
  activation_rules {
    approval_stage {
      primary_approver {
        object_id = azuread_group.rbac_keyvault_group[each.key].object_id
        type      = var.pim_policy.activation_rules.approval_stage.primary_approver.type
      }
    }
    maximum_duration                   = var.pim_policy.activation_rules.maximum_duration
    require_approval                   = var.pim_policy.activation_rules.require_approval
    require_justification              = var.pim_policy.activation_rules.require_justification
    require_multifactor_authentication = var.pim_policy.activation_rules.require_multifactor_authentication
  }
}

resource "azuread_group_role_management_policy" "acr_group" {
  for_each = var.pim_enabled ? local.group_names_map_acr : {}
  group_id = azuread_group.rbac_acr_group[each.key].id
  role_id  = var.pim_policy.role_id

  eligible_assignment_rules {
    expiration_required = var.pim_policy.eligible_assignment_rules.expiration_required
  }
  activation_rules {
    approval_stage {
      primary_approver {
        object_id = azuread_group.rbac_acr_group[each.key].object_id
        type      = var.pim_policy.activation_rules.approval_stage.primary_approver.type
      }
    }
    maximum_duration                   = var.pim_policy.activation_rules.maximum_duration
    require_approval                   = var.pim_policy.activation_rules.require_approval
    require_justification              = var.pim_policy.activation_rules.require_justification
    require_multifactor_authentication = var.pim_policy.activation_rules.require_multifactor_authentication
  }
}
