# Create Azure Container Registry
resource "azurerm_container_registry" "acr" {
  #checkov:skip=CKV_AZURE_164: "Ensures that ACR uses signed/trusted images"
  # This settings is optional and default set to false to prevent having to sign all images
  count               = try(var.acr_existing_acr_id, null) != null ? 0 : 1
  name                = "acr${var.shortname}001"
  resource_group_name = azurerm_resource_group.aks_resources.name
  location            = azurerm_resource_group.aks_resources.location
  sku                 = var.acr_sku
  admin_enabled       = var.acr_admin_enabled

  public_network_access_enabled = var.acr_public_network_access_enabled
  export_policy_enabled         = var.acr_export_policy_enabled
  zone_redundancy_enabled       = var.acr_zone_redundancy_enabled

  georeplications {
    location                = var.acr_georeplication_location
    zone_redundancy_enabled = var.acr_zone_redundancy_enabled
    tags                    = local.tags
  }

  trust_policy = [{
    enabled = var.acr_trust_policy_enabled
  }]

  retention_policy = [var.acr_retention_policy_enabled]

  quarantine_policy_enabled = var.acr_quarantine_policy_enabled

  tags = local.tags
}

# Add private Endpoint
resource "azurerm_private_endpoint" "acr_private_endpoint" {
  count               = try(var.acr_existing_acr_id, null) != null ? 0 : 1
  name                = "pep-registry-${var.fullname}-001"
  resource_group_name = azurerm_resource_group.aks_resources.name
  location            = azurerm_resource_group.aks_resources.location
  subnet_id           = var.private_endpoint_subnet_id

  private_service_connection {
    name                           = "psc-registry-${var.fullname}-001"
    is_manual_connection           = false
    private_connection_resource_id = azurerm_container_registry.acr[0].id
    subresource_names = [
      "registry"
    ]
  }

  tags = local.tags

  lifecycle {
    ignore_changes = [
      private_dns_zone_group
    ]
  }
}

resource "azurerm_monitor_diagnostic_setting" "acr" {
  count                      = try(var.acr_existing_acr_id, null) != null ? 0 : 1
  name                       = "acr-logging"
  log_analytics_workspace_id = try(azurerm_log_analytics_workspace.law_aks[0].id, var.law_id)
  target_resource_id         = azurerm_container_registry.acr[0].id
  enabled_log {
    category_group = "allLogs"
  }

  metric {
    category = "AllMetrics"
    enabled  = var.diagnostic_metrics_enabled
  }
}
