variable "acr_sku" {
  type        = string
  description = "The sku to be used for the ACR."
  default     = "Premium"
}

variable "acr_admin_enabled" {
  type        = bool
  description = "Specify if admin access should be enabled. Default is false."
  default     = false
}

variable "acr_existing_acr_id" {
  type        = string
  description = "The ID of the existing ACR."
  default     = null
}

variable "acr_public_network_access_enabled" {
  type        = bool
  description = "Enable public network access to the ACR."
  default     = false
}

variable "acr_export_policy_enabled" {
  type        = bool
  description = "Enable export policy for the ACR."
  default     = false
}

variable "acr_zone_redundancy_enabled" {
  type        = bool
  description = "Enable zone redundancy for the ACR."
  default     = true
}

variable "acr_trust_policy_enabled" {
  type        = bool
  description = "Enable trust policy for the ACR."
  default     = false
}

variable "acr_retention_policy_enabled" {
  type = object({
    enabled = bool
    days    = number
  })
  description = "Enable retention policy for the ACR."
  default = {
    enabled = true
    days    = 31
  }
}

variable "acr_quarantine_policy_enabled" {
  type        = bool
  description = "Enable quarantine policy for the ACR."
  default     = true
}

variable "acr_georeplication_location" {
  type        = string
  description = "The location of the georeplication."
  default     = "northeurope"
}

variable "rbac_roles_acr" {
  description = "Map of RBAC roles for the acr"
  type        = list(string)
  default = [
    "AcrDelete",
    "AcrImageSigner",
    "AcrPull",
    "AcrPush",
    "AcrQuarantineReader",
    "AcrQuarantineWriter"
  ]
}

variable "group_names_acr" {
  description = "name of different groups created for the acr"
  type = object({
    AcrDelete           = optional(string)
    AcrImageSigner      = optional(string)
    AcrPull             = optional(string)
    AcrPush             = optional(string)
    AcrQuarantineReader = optional(string)
    AcrQuarantineWriter = optional(string)
  })
  default = {
    AcrDelete           = null
    AcrImageSigner      = null
    AcrPull             = null
    AcrPush             = null
    AcrQuarantineReader = null
    AcrQuarantineWriter = null
  }
}
