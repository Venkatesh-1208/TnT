resource "azuread_group" "azurekubernetesservicerbacadmin_group" {
  display_name            = coalesce(var.group_names.AzureKubernetesServiceRBACAdmin, "RES_${azurerm_kubernetes_cluster.aks.name}_Azure Kubernetes Service RBAC Admin")
  description             = "AKS RBAC Admin role for the ${azurerm_kubernetes_cluster.aks.name} resource"
  security_enabled        = true
  assignable_to_role      = false
  prevent_duplicate_names = true
}

resource "azuread_group" "azurekubernetesservicerbacclusteradmin_group" {
  display_name            = coalesce(var.group_names.AzureKubernetesServiceRBACClusterAdmin, "RES_${azurerm_kubernetes_cluster.aks.name}_Azure Kubernetes Service RBAC Cluster Admin")
  description             = "AKS RBAC Cluster Admin role for the ${azurerm_kubernetes_cluster.aks.name} resource"
  security_enabled        = true
  assignable_to_role      = false
  prevent_duplicate_names = true
}

resource "azuread_group" "azurekubernetesservicerbacreader_group" {
  display_name            = coalesce(var.group_names.AzureKubernetesServiceRBACReader, "RES_${azurerm_kubernetes_cluster.aks.name}_Azure Kubernetes Service RBAC Reader")
  description             = "AKS RBAC Reader role for the ${azurerm_kubernetes_cluster.aks.name} resource"
  security_enabled        = true
  assignable_to_role      = false
  prevent_duplicate_names = true
}

resource "azuread_group" "azurekubernetesservicerbacwriter_group" {
  display_name            = coalesce(var.group_names.AzureKubernetesServiceRBACWriter, "RES_${azurerm_kubernetes_cluster.aks.name}_Azure Kubernetes Service RBAC Writer")
  description             = "AKS RBAC Writer role for the ${azurerm_kubernetes_cluster.aks.name} resource"
  security_enabled        = true
  assignable_to_role      = false
  prevent_duplicate_names = true
}

resource "azurerm_role_assignment" "azurekubernetesservicerbacadmin_role_assignment" {
  scope                = azurerm_kubernetes_cluster.aks.id
  role_definition_name = "Azure Kubernetes Service RBAC Admin"
  principal_id         = azuread_group.azurekubernetesservicerbacadmin_group.id
}

resource "azurerm_role_assignment" "azurekubernetesservicerbacclusteradmin_role_assignment" {
  scope                = azurerm_kubernetes_cluster.aks.id
  role_definition_name = "Azure Kubernetes Service RBAC Cluster Admin"
  principal_id         = azuread_group.azurekubernetesservicerbacclusteradmin_group.id
}

resource "azurerm_role_assignment" "azurekubernetesservicerbacreader_role_assignment" {
  scope                = azurerm_kubernetes_cluster.aks.id
  role_definition_name = "Azure Kubernetes Service RBAC Reader"
  principal_id         = azuread_group.azurekubernetesservicerbacreader_group.id
}

resource "azurerm_role_assignment" "azurekubernetesservicerbacwriter_role_assignment" {
  scope                = azurerm_kubernetes_cluster.aks.id
  role_definition_name = "Azure Kubernetes Service RBAC Writer"
  principal_id         = azuread_group.azurekubernetesservicerbacwriter_group.id
}
