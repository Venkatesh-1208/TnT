resource "azurerm_log_analytics_workspace" "law_aks" {
  count               = try(var.law_id, null) != null ? 0 : 1
  name                = "law-${var.fullname}-001"
  location            = azurerm_resource_group.aks_resources.location
  resource_group_name = azurerm_resource_group.aks_resources.name
  sku                 = var.law_sku
  retention_in_days   = var.law_retention_in_days

  tags = local.tags
}

resource "azurerm_monitor_diagnostic_setting" "law" {
  count                      = try(var.law_id, null) != null ? 0 : 1
  name                       = "law-logging"
  log_analytics_workspace_id = try(azurerm_log_analytics_workspace.law_aks[0].id, var.law_id)
  target_resource_id         = azurerm_log_analytics_workspace.law_aks[0].id
  enabled_log {
    category_group = "allLogs"
  }

  metric {
    category = "AllMetrics"
    enabled  = var.diagnostic_metrics_enabled
  }
}
