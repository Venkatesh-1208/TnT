locals {
  group_names_map_acr = {
    "AcrDelete"           = coalesce(var.group_names_acr.AcrDelete, "RES_${var.shortname}001_${var.rbac_roles_acr[0]}")
    "AcrImageSigner"      = coalesce(var.group_names_acr.AcrImageSigner, "RES_${var.shortname}001_${var.rbac_roles_acr[1]}")
    "AcrPull"             = coalesce(var.group_names_acr.AcrPull, "RES_${var.shortname}001_${var.rbac_roles_acr[2]}")
    "AcrPush"             = coalesce(var.group_names_acr.AcrPush, "RES_${var.shortname}001_${var.rbac_roles_acr[3]}")
    "AcrQuarantineReader" = coalesce(var.group_names_acr.AcrQuarantineReader, "RES_${var.shortname}001_${var.rbac_roles_acr[4]}")
    "AcrQuarantineWriter" = coalesce(var.group_names_acr.AcrQuarantineWriter, "RES_${var.shortname}001_${var.rbac_roles_acr[5]}")
  }
}

resource "azuread_group" "rbac_acr_group" {
  for_each                = local.group_names_map_acr
  display_name            = each.value
  description             = "${each.key} Role for Azure Container Registry"
  security_enabled        = true
  assignable_to_role      = false
  prevent_duplicate_names = true
}

resource "azurerm_role_assignment" "acr_role_assignments" {
  for_each             = local.group_names_map_acr
  scope                = var.acr_existing_acr_id != null ? var.acr_existing_acr_id : azurerm_container_registry.acr[0].id
  role_definition_name = each.key
  principal_id         = azuread_group.rbac_acr_group[each.key].object_id
}