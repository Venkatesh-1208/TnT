resource "azurerm_kubernetes_cluster_node_pool" "nodepool" {
  #checkov:skip=CKV_AZURE_227: "Ensure that the AKS cluster encrypt temp disks, caches, and data flows between Compute and Storage resources"
  #checkov:skip=CKV_AZURE_168: "Ensure Azure Kubernetes Cluster (AKS) nodes should use a minimum number of 50 pods."
  # The default value for the max_pods variable is set to 50
  count                  = var.aks_number_of_node_pools
  name                   = "pool00${count.index + 1}" # maximum of 12 characters
  kubernetes_cluster_id  = azurerm_kubernetes_cluster.aks.id
  vm_size                = var.aks_nodepools_config["pool00${count.index + 1}"].vm_size
  min_count              = var.aks_nodepools_config["pool00${count.index + 1}"].min_count
  max_count              = var.aks_nodepools_config["pool00${count.index + 1}"].max_count
  enable_auto_scaling    = var.aks_nodepools_config["pool00${count.index + 1}"].enable_auto_scaling
  enable_host_encryption = var.aks_nodepools_config["pool00${count.index + 1}"].enable_host_encryption
  max_pods               = var.aks_nodepools_config["pool00${count.index + 1}"].max_pods
  os_disk_type           = var.aks_nodepools_config["pool00${count.index + 1}"].os_disk_type
  vnet_subnet_id         = var.aks_workload_subnet_ids[count.index]
  pod_subnet_id          = var.aks_workload_pods_subnet_ids[count.index]
  zones                  = var.aks_availability_zones
  orchestrator_version    = var.aks_version

  upgrade_settings {
    drain_timeout_in_minutes      = var.aks_nodepools_upgrade_settings.drain_timeout_in_minutes
    max_surge                     = var.aks_nodepools_upgrade_settings.max_surge
    node_soak_duration_in_minutes = var.aks_nodepools_upgrade_settings.node_soak_duration_in_minutes
  }

  tags = local.tags
}
