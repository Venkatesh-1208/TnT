data "azurerm_subscription" "current" {}

data "azuread_client_config" "current" {}

resource "azurerm_key_vault" "keyvault" {
  # checkov:skip=CKV_AZURE_189: "Ensure that Azure Key Vault disables public network access"
  # checkov:skip=CKV2_AZURE_32: "Ensure private endpoint is configured to key vault"
  # Both lines need to be there because we want to be able to deploy a key vault with private endpoint or with an ip filter (public access).
  count               = try(var.key_vault_id, null) != null ? 0 : 1
  name                = lower("kv${var.shortname}001")
  location            = azurerm_resource_group.aks_resources.location
  resource_group_name = azurerm_resource_group.aks_resources.name
  tenant_id           = data.azurerm_subscription.current.tenant_id

  sku_name                   = var.key_vault_configuration.sku_name
  soft_delete_retention_days = var.key_vault_configuration.soft_delete_retention_days

  purge_protection_enabled        = var.key_vault_configuration.purge_protection_enabled
  enable_rbac_authorization       = var.key_vault_configuration.enable_rbac_authorization
  enabled_for_deployment          = var.key_vault_configuration.enabled_for_deployment
  enabled_for_disk_encryption     = var.key_vault_configuration.enabled_for_disk_encryption
  enabled_for_template_deployment = var.key_vault_configuration.enabled_for_template_deployment
  public_network_access_enabled   = var.key_vault_configuration.public_network_access_enabled

  network_acls {
    bypass                     = var.key_vault_configuration.network_acls.bypass
    default_action             = var.key_vault_configuration.network_acls.default_action
    ip_rules                   = var.key_vault_configuration.network_acls.ip_rules
    virtual_network_subnet_ids = var.key_vault_configuration.network_acls.virtual_network_subnet_ids
  }
  tags = local.tags
}

# private endpoint for kv
resource "azurerm_private_endpoint" "kv_private_endpoint" {
  count               = try(var.key_vault_id, null) != null ? 0 : 1
  name                = lower("pep-vault-${var.fullname}-001")
  resource_group_name = azurerm_resource_group.aks_resources.name
  location            = azurerm_resource_group.aks_resources.location
  subnet_id           = var.private_endpoint_subnet_id
  private_service_connection {
    name                           = "psc-vault-${var.fullname}-001"
    is_manual_connection           = false
    private_connection_resource_id = azurerm_key_vault.keyvault[0].id
    subresource_names = [
      "vault"
    ]
  }

  tags = local.tags

  lifecycle {
    ignore_changes = [
      private_dns_zone_group
    ]
  }
}

# Permissions for the current user
resource "azurerm_role_assignment" "role_assignments_current_user" {
  count                = try(var.key_vault_id, null) != null ? 0 : 1
  scope                = azurerm_key_vault.keyvault[0].id
  role_definition_name = "Key Vault Administrator"
  principal_id         = data.azuread_client_config.current.object_id

  provisioner "local-exec" {
    command = "sleep 60"
  }
}

# Diagnostic settings for key vault
resource "azurerm_monitor_diagnostic_setting" "kv_logs" {
  count                      = try(var.key_vault_id, null) != null ? 0 : 1
  name                       = "keyvault-logging"
  log_analytics_workspace_id = try(azurerm_log_analytics_workspace.law_aks[0].id, var.law_id)
  target_resource_id         = azurerm_key_vault.keyvault[0].id
  enabled_log {
    category_group = "allLogs"
  }

  metric {
    category = "AllMetrics"
    enabled  = var.diagnostic_metrics_enabled
  }
}
