variable "key_vault_configuration" {
  type = object({
    sku_name                        = optional(string, "standard")
    soft_delete_retention_days      = optional(number, 90)
    purge_protection_enabled        = optional(bool, true)
    enable_rbac_authorization       = optional(bool, true)
    enabled_for_deployment          = optional(bool, false)
    enabled_for_disk_encryption     = optional(bool, false)
    enabled_for_template_deployment = optional(bool, false)
    public_network_access_enabled   = optional(bool, false)
    network_acls = optional(object({
      bypass                     = optional(string, "AzureServices")
      default_action             = optional(string, "Deny")
      ip_rules                   = optional(list(string), [])
      virtual_network_subnet_ids = optional(list(string), [])
      }), {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    })
  })
  description = "The configuration of the key vault."
  default = {
    sku_name                        = "standard"
    soft_delete_retention_days      = 90
    purge_protection_enabled        = true
    enable_rbac_authorization       = true
    enabled_for_deployment          = false
    enabled_for_disk_encryption     = false
    enabled_for_template_deployment = false
    public_network_access_enabled   = false
    network_acls = {
      bypass         = "AzureServices"
      default_action = "Deny"
      ip_rules       = []
    }
  }
}

variable "rbac_roles_kv" {
  description = "Map of RBAC roles for the key vault"
  type        = list(string)
  default = [
    "Key Vault Administrator",
    "Key Vault Certificate User",
    "Key Vault Certificates Officer",
    "Key Vault Contributor",
    "Key Vault Crypto Officer",
    "Key Vault Crypto Service Encryption User",
    "Key Vault Crypto Service Release User",
    "Key Vault Crypto User",
    "Key Vault Data Access Administrator",
    "Key Vault Reader",
    "Key Vault Secrets Officer",
    "Key Vault Secrets User"
  ]
}

variable "group_names_kv" {
  description = "name of different groups created for the key vault"
  type = object({
    Administrator                  = optional(string)
    Certificates_User              = optional(string)
    Certificates_Officer           = optional(string)
    Contributor                    = optional(string)
    Crypto_Officer                 = optional(string)
    Crypto_Service_Encryption_User = optional(string)
    Crypto_Service_Release_User    = optional(string)
    Crypto_User                    = optional(string)
    Data_Access_Administrator      = optional(string)
    Reader                         = optional(string)
    Secrets_Officer                = optional(string)
    Secrets_User                   = optional(string)
  })
  default = {
    Administrator                  = null
    Certificates_User              = null
    Certificates_Officer           = null
    Contributor                    = null
    Crypto_Officer                 = null
    Crypto_Service_Encryption_User = null
    Crypto_Service_Release_User    = null
    Crypto_User                    = null
    Data_Access_Administrator      = null
    Reader                         = null
    Secrets_Officer                = null
    Secrets_User                   = null
  }
}
