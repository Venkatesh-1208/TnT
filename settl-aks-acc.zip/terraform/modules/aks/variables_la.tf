variable "law_sku" {
  description = "The SKU of the Log Analytics Workspace"
  type        = string
  default     = "PerGB2018"
}

variable "law_retention_in_days" {
  description = "The retention in days of the Log Analytics Workspace"
  type        = number
  default     = 30
}

variable "law_id" {
  type        = string
  description = "The ID of the log analytics workspace."
  default     = null
}