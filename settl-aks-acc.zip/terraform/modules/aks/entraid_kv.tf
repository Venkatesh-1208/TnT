locals {
  group_names_map_kv = {
    "Administrator"                  = coalesce(var.group_names_kv.Administrator, "RES_${var.shortname}001_${var.rbac_roles_kv[0]}")
    "Certificate User"               = coalesce(var.group_names_kv.Certificates_User, "RES_${var.shortname}001_${var.rbac_roles_kv[1]}")
    "Certificates Officer"           = coalesce(var.group_names_kv.Certificates_Officer, "RES_${var.shortname}001_${var.rbac_roles_kv[2]}")
    "Contributor"                    = coalesce(var.group_names_kv.Contributor, "RES_${var.shortname}001_${var.rbac_roles_kv[3]}")
    "Crypto Officer"                 = coalesce(var.group_names_kv.Crypto_Officer, "RES_${var.shortname}001_${var.rbac_roles_kv[4]}")
    "Crypto Service Encryption User" = coalesce(var.group_names_kv.Crypto_Service_Encryption_User, "RES_${var.shortname}001_${var.rbac_roles_kv[5]}")
    "Crypto Service Release User"    = coalesce(var.group_names_kv.Crypto_Service_Release_User, "RES_${var.shortname}001_${var.rbac_roles_kv[6]}")
    "Crypto User"                    = coalesce(var.group_names_kv.Crypto_User, "RES_${var.shortname}001_${var.rbac_roles_kv[7]}")
    "Data Access Administrator"      = coalesce(var.group_names_kv.Data_Access_Administrator, "RES_${var.shortname}001_${var.rbac_roles_kv[8]}")
    "Reader"                         = coalesce(var.group_names_kv.Reader, "RES_${var.shortname}001_${var.rbac_roles_kv[9]}")
    "Secrets Officer"                = coalesce(var.group_names_kv.Secrets_Officer, "RES_${var.shortname}001_${var.rbac_roles_kv[10]}")
    "Secrets User"                   = coalesce(var.group_names_kv.Secrets_User, "RES_${var.shortname}001_${var.rbac_roles_kv[11]}")
  }
}

resource "azuread_group" "rbac_keyvault_group" {
  for_each                = local.group_names_map_kv
  display_name            = each.value
  description             = "${each.key} Role for Key Vault"
  security_enabled        = true
  assignable_to_role      = false
  prevent_duplicate_names = true
}

resource "azurerm_role_assignment" "keyvault_role_assignments" {
  for_each             = local.group_names_map_kv
  scope                = azurerm_key_vault.keyvault[0].id
  role_definition_name = "Key Vault ${each.key}"
  principal_id         = azuread_group.rbac_keyvault_group[each.key].object_id
}