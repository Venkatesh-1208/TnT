resource "azurerm_resource_group" "aks_resources" {
  name     = "rg-${var.fullname}-001"
  location = var.location

  tags = local.tags
}

resource "azurerm_user_assigned_identity" "aks_user_assigned_identity" {
  resource_group_name = azurerm_resource_group.aks_resources.name
  location            = azurerm_resource_group.aks_resources.location
  name                = "id-${var.fullname}-001"

  tags = local.tags
}

# Allow aks to manage the private dns zone
resource "azurerm_role_assignment" "aks_private_dns_zone_contributor" {
  scope                = var.aks_dns_id
  role_definition_name = "Private DNS Zone Contributor"
  principal_id         = azurerm_user_assigned_identity.aks_user_assigned_identity.principal_id
}

resource "azurerm_role_assignment" "role_assignments" {
  scope                = try(azurerm_key_vault.keyvault[0].id, var.key_vault_id)
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azurerm_user_assigned_identity.aks_user_assigned_identity.principal_id
}

resource "azurerm_role_assignment" "aks_vnet_role_assignments" {
  scope                = var.aks_vnet_id
  role_definition_name = "Network Contributor"
  principal_id         = azurerm_user_assigned_identity.aks_user_assigned_identity.principal_id
}

# AKS cluster
resource "azurerm_kubernetes_cluster" "aks" {
  #checkov:skip=CKV_AZURE_226: "Ensure ephemeral disks are used for OS disks"
  # It is a design decision to not use ephemeral disks for OS disks
  #checkov:skip=CKV_AZURE_117: "Ensure that AKS uses disk encryption set"
  # Use of disk encryption set is optional
  #checkov:skip=CKV_AZURE_168: "Ensure Azure Kubernetes Cluster (AKS) nodes should use a minimum number of 50 pods"
  # The default value for the max_pods variable is set to 50
  name                      = "aks-${var.fullname}-001"
  location                  = azurerm_resource_group.aks_resources.location
  resource_group_name       = azurerm_resource_group.aks_resources.name
  automatic_channel_upgrade = var.aks_automatic_channel_upgrade
  azure_policy_enabled      = var.aks_azure_policy_enabled
  cost_analysis_enabled     = var.aks_cost_analysis_enabled
  sku_tier                  = var.aks_sku_tier

  disk_encryption_set_id = var.aks_enable_disk_encryption ? azurerm_disk_encryption_set.des_aks[0].id : null

  oms_agent {
    log_analytics_workspace_id = try(azurerm_log_analytics_workspace.law_aks[0].id, var.law_id)
    msi_auth_for_monitoring_enabled = var.aks_oms_agent_msi_auth_for_monitoring_enabled
  }

  oidc_issuer_enabled       = var.aks_oidc_issuer_enabled
  workload_identity_enabled = var.aks_workload_identity_enabled

  identity {
    type         = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.aks_user_assigned_identity.id]
  }

  ingress_application_gateway {
    gateway_id = azurerm_application_gateway.appgw.id
  }

  default_node_pool {
    name                         = trim(lower("system"), 12) # maximum of 12 characters
    vm_size                      = var.aks_system_nodes_config.vm_size
    min_count                    = var.aks_system_nodes_config.min_count
    max_count                    = var.aks_system_nodes_config.max_count
    enable_auto_scaling          = var.aks_system_nodes_config.enable_auto_scaling
    enable_host_encryption       = var.aks_system_nodes_config.enable_host_encryption
    max_pods                     = var.aks_system_nodes_config.max_pods
    only_critical_addons_enabled = var.aks_system_nodes_config.only_critical_addons_enabled
    os_disk_type                 = var.aks_system_nodes_config.os_disk_type
    vnet_subnet_id               = var.aks_system_nodes_subnet_ids[0]
    pod_subnet_id                = var.aks_system_pods_subnet_ids[0]
    zones                        = var.aks_availability_zones
    orchestrator_version         = var.aks_version

    upgrade_settings {
      drain_timeout_in_minutes      = var.aks_system_nodes_upgrade_settings.drain_timeout_in_minutes
      max_surge                     = var.aks_system_nodes_upgrade_settings.max_surge
      node_soak_duration_in_minutes = var.aks_system_nodes_upgrade_settings.node_soak_duration_in_minutes
    }

    temporary_name_for_rotation = "tempsystem"
    tags                        = local.tags

  }

  dns_prefix_private_cluster = trim(var.shortname, 54) # maximum of 54 characters

  kubernetes_version     = var.aks_version
  local_account_disabled = var.aks_local_account_disabled

  network_profile {
    network_plugin = var.aks_network_profile.network_plugin
    network_mode   = var.aks_network_profile.network_mode
    network_policy = var.aks_network_profile.network_policy
    outbound_type  = var.aks_network_profile.outbound_type
    service_cidr   = var.aks_network_profile.service_cidr
    dns_service_ip = var.aks_network_profile.dns_service_ip
  }

  storage_profile {
    blob_driver_enabled = var.aks_storage_profile.blob_driver_enabled
    disk_driver_enabled = var.aks_storage_profile.disk_driver_enabled
  }

  key_vault_secrets_provider {
    secret_rotation_enabled = var.aks_secret_rotation_enabled
  }

  azure_active_directory_role_based_access_control {
    azure_rbac_enabled = var.aks_active_directory_role_based_access_control.azure_rbac_enabled
    managed            = var.aks_active_directory_role_based_access_control.managed
    # The property managed is deprecated and will be defaulted to true in v4.0 of the AzureRM provider.
    # Until the property is removed it must be specified with true for AKS-managed Entra Integration.
  }

  dynamic "monitor_metrics" {
    for_each = var.monitor_metrics != null ? [1] : []
    content {
      annotations_allowed = var.monitor_metrics.annotations_allowed
      labels_allowed      = var.monitor_metrics.labels_allowed
    }
  }

  node_resource_group     = "rg-${var.fullname}-nodes-001"
  run_command_enabled     = var.aks_run_command_enabled
  private_cluster_enabled = var.aks_private_cluster_enabled
  private_dns_zone_id     = var.aks_dns_id

  tags = local.tags
}

# Permissions for AKS on ApGW
data "azurerm_user_assigned_identity" "aks_ingress_uaid" {
  depends_on = [
    azurerm_kubernetes_cluster.aks
  ]
  name                = "ingressapplicationgateway-aks-${var.fullname}-001"
  resource_group_name = "rg-${var.fullname}-nodes-001"
}

# Pull permissions on ACR
resource "azurerm_role_assignment" "aks_permissions_on_acr" {
  scope                            = try(azurerm_container_registry.acr[0].id, var.acr_existing_acr_id)
  role_definition_name             = "AcrPull"
  principal_id                     = azurerm_kubernetes_cluster.aks.kubelet_identity[0].object_id
  skip_service_principal_aad_check = true
}

resource "azurerm_role_assignment" "aks_ingress_uaid_permissions_on_vnet" {
  scope                = var.aks_vnet_id
  role_definition_name = "Contributor"
  principal_id         = data.azurerm_user_assigned_identity.aks_ingress_uaid.principal_id
}

# Assign read permissions on the resource group where the application gateway is located to the user managed identity used for the ingress controller
resource "azurerm_role_assignment" "aks_ingress_uaid_reader_on_apgw_resource_group" {
  scope                = azurerm_resource_group.aks_resources.id
  role_definition_name = "Contributor" # or is Reader Sufficient?
  principal_id         = data.azurerm_user_assigned_identity.aks_ingress_uaid.principal_id
}

resource "azurerm_monitor_diagnostic_setting" "aks" {
  name                       = "aks-logging"
  log_analytics_workspace_id = try(azurerm_log_analytics_workspace.law_aks[0].id, var.law_id)
  target_resource_id         = azurerm_kubernetes_cluster.aks.id
  enabled_log {
    category_group = "allLogs"
  }

  enabled_log {
    category_group = "audit"
  }

  metric {
    category = "AllMetrics"
    enabled  = var.diagnostic_metrics_enabled
  }
}
