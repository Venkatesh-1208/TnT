output "kubernetes_cluster" {
  description = "The AKS cluster Details"
  value       = azurerm_kubernetes_cluster.aks
  sensitive   = true
}
output "application-gateway" {
  description = "The AKS module Key vault Details"
  value       = azurerm_application_gateway.appgw
  sensitive   = true
}
output "appgw-public-ip" {
  description = "The AKS module Key vault Details"
  value       = azurerm_public_ip.appgw_pip.ip_address
}
output "appgw-waf-policy" {
  description = "The Application GW WAF Policy Id"
  value       = azurerm_web_application_firewall_policy.wafpolicy-default-aks
}

output "log_analytics_workspace_id" {
  description = "The ID of the Log Analytics workspace used by AKS."
  value       = try(azurerm_log_analytics_workspace.law_aks[0].id, var.law_id)
}
