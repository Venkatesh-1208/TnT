resource "azurerm_resource_provider_registration" "monitor" {
  name = "Microsoft.Monitor"
}
resource "azurerm_resource_provider_registration" "dashboard" {
  name = "Microsoft.Dashboard"
}

resource "azurerm_monitor_workspace" "amw" {
  name                = "mon-${var.fullname}-001"
  resource_group_name = var.resource_group_name
  location            = var.location

  public_network_access_enabled = false

  tags = local.tags
}

resource "azurerm_private_endpoint" "monitor_private_endpoint" {
  name                = lower("pep-mon-${var.fullname}-001")
  resource_group_name = var.resource_group_name
  location            = var.location
  subnet_id           = var.private_endpoint_subnet_id
  private_service_connection {
    name                           = "psc-mon-${var.fullname}-001"
    is_manual_connection           = false
    private_connection_resource_id = azurerm_monitor_workspace.amw.id
    subresource_names = [
      "prometheusMetrics"
    ]
  }

  tags = local.tags

  lifecycle {
    ignore_changes = [
      private_dns_zone_group
    ]
  }
}

resource "azurerm_monitor_data_collection_endpoint" "dce" {
  name                = "dce-${var.fullname}-001"
  resource_group_name = var.resource_group_name
  location            = var.location
  kind                = "Linux"

  tags = local.tags
}

resource "azurerm_monitor_data_collection_rule" "dcr" {
  name                        = "dcr-${var.fullname}-001"
  resource_group_name         = var.resource_group_name
  location                    = var.location
  data_collection_endpoint_id = azurerm_monitor_data_collection_endpoint.dce.id
  kind                        = "Linux"

  destinations {
    monitor_account {
      monitor_account_id = azurerm_monitor_workspace.amw.id
      name               = "ma-${var.fullname}-001"
    }
  }

  data_flow {
    streams      = ["Microsoft-PrometheusMetrics"]
    destinations = ["ma-${var.fullname}-001"]
  }

  data_sources {
    prometheus_forwarder {
      streams = ["Microsoft-PrometheusMetrics"]
      name    = "ds-${var.fullname}-001"
    }
  }

  description = "DCR for Azure Monitor Metrics Profile (Managed Prometheus)"
  depends_on = [
    azurerm_monitor_data_collection_endpoint.dce
  ]

  tags = local.tags
}

resource "azurerm_monitor_data_collection_rule_association" "dcra" {
  lifecycle {
    ignore_changes = [
       target_resource_id
    ]
  }
  name                    = "dcra-${var.fullname}-001"
  target_resource_id      = var.aks_id
  data_collection_rule_id = azurerm_monitor_data_collection_rule.dcr.id
  description             = "Association of data collection rule. Deleting this association will break the data collection for this AKS Cluster."
  depends_on = [
    azurerm_monitor_data_collection_rule.dcr
  ]
}

resource "azurerm_role_assignment" "amw_owner" {
  scope                = azurerm_monitor_workspace.amw.id
  role_definition_name = "Owner"
  principal_id         = "b3e8e3a7-c967-4e2c-b32b-e8ff9fc51a9a"
}
