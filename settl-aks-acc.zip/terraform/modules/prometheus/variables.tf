variable "fullname" {
  type        = string
  description = "Fullname for the resources."
}

variable "location" {
  description = "Location to provision resources in."
  type        = string
  default     = "westeurope"
}

variable "resource_group_name" {
  description = "Resource group to deploy resources in."
  type        = string  
}

variable "aks_id" {
  description = "The ID of the AKS cluster to deploy Grafana for"
  type        = string  
}

variable "private_endpoint_subnet_id" {
  type        = string
  description = "The id of the subnet for the private endpoints."
}

variable "mandatory_tags" {
  description = "mandatory_tags"
  type        = any
}

variable "optional_tags" {
  description = "optional_tags"
  type = object({
    IaaSBackupSchedule   = optional(string)
    IaaSPowerOffSchedule = optional(string)
    IaaSPowerOnSchedule  = optional(string)
    IaaSUpdateSchedule   = optional(string)
    SandboxEndDate       = optional(string)
    Entity               = optional(string)
  })
  default = null
}