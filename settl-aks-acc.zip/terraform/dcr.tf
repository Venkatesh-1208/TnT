
resource "azurerm_monitor_data_collection_rule" "aks_ci" {
  count               = var.container_log_v2_enabled ? 1 : 0
  name                = "dcr-${local.aks.fullname}-ci-001"
  location            = azurerm_resource_group.aks_resources.location
  resource_group_name = azurerm_resource_group.aks_resources.name
  kind                = "Linux"
  destinations {
    log_analytics {
      name                  = "lawdest"
      workspace_resource_id = module.aks.log_analytics_workspace_id
    }
  }
  data_sources {
    extension {
      name           = "ContainerInsightsExtension"
      extension_name = "ContainerInsights"
      streams = [
        "Microsoft-ContainerLogV2",
        "Microsoft-KubeEvents",
        "Microsoft-KubePodInventory",
        "Microsoft-KubeNodeInventory",
        "Microsoft-KubeServices",
        "Microsoft-KubePVInventory",
        "Microsoft-KubeMonAgentEvents",
        "Microsoft-InsightsMetrics"
      ]
      extension_json = jsonencode({
        dataCollectionSettings = {
          enableContainerLogV2 = var.container_log_v2_enabled
        }
      })
    }
  }
  data_flow {
    streams = [
      "Microsoft-ContainerLogV2",
      "Microsoft-KubeEvents",
      "Microsoft-KubePodInventory",
      "Microsoft-KubeNodeInventory",
      "Microsoft-KubeServices",
      "Microsoft-KubePVInventory",
      "Microsoft-KubeMonAgentEvents",
      "Microsoft-InsightsMetrics"
    ]
    destinations = ["lawdest"]
  }
}

resource "azurerm_monitor_data_collection_rule_association" "aks_ci" {
  count                   = var.container_log_v2_enabled ? 1 : 0
  name                    = "dcra-${local.aks.fullname}-ci-001"
  target_resource_id      = data.azurerm_kubernetes_cluster.aks.id
  data_collection_rule_id = azurerm_monitor_data_collection_rule.aks_ci[0].id
}
