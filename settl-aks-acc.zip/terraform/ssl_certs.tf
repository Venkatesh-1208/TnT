# The PFX password must already exist in Key Vault.
data "azurerm_key_vault_secret" "argocd_pfx_password" {
  count = local.argocd_domain_is_present ? 1 : 0

  name = format(
    "%s-pfx-password",
    replace(local.aks.argocd_domain, ".", "-")
  )

  key_vault_id = data.azurerm_key_vault.aks_kv.id
}

# Import the Argo CD PFX certificate into Key Vault.
resource "azurerm_key_vault_certificate" "argocd_ssl_certificate" {
  count = local.argocd_domain_is_present ? 1 : 0

  name = replace(
    local.aks.argocd_domain,
    ".",
    "-"
  )

  key_vault_id = data.azurerm_key_vault.aks_kv.id

  certificate {
    contents = filebase64(
      "${path.module}/../ssl_certs/${local.aks.argocd_domain}.pfx"
    )

    password = data.azurerm_key_vault_secret.argocd_pfx_password[count.index].value
  }

  lifecycle {
    ignore_changes = [
      certificate_policy
    ]
  }
}


// #This secret should be created manually before running this module or pipeline
// data "azurerm_key_vault_secret" "argocd_pfx_password" {
//   count        = local.argocd_domain_is_present ? 1 : 0
//   name         = format("%s-pfx-password", replace(local.aks.argocd_domain, ".", "-"))
//   key_vault_id = "/subscriptions/ca0752e6-7c8f-46f8-9aa5-160259aca716/resourceGroups/rg-cf-settl-acc-euw-aks-001/providers/Microsoft.KeyVault/vaults/kvcfsettlacceuwaks001"
// }
// resource "azurerm_key_vault_certificate" "argocd_ssl_certificate" {
//   count        = local.argocd_domain_is_present ? 1 : 0
//   name         = replace(local.aks.argocd_domain, ".", "-")
//   key_vault_id = "/subscriptions/ca0752e6-7c8f-46f8-9aa5-160259aca716/resourceGroups/rg-cf-settl-acc-euw-aks-001/providers/Microsoft.KeyVault/vaults/kvcfsettlacceuwaks001"

//   certificate {
//     contents = filebase64("${path.module}/../ssl_certs/${local.aks.argocd_domain}.pfx")
//     password = data.azurerm_key_vault_secret.argocd_pfx_password[count.index].value
//   }
//   lifecycle {
//     ignore_changes = [certificate_policy]
//   }
// }