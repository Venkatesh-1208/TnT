variable "dtap_environment" {
  description = "DTAP environment"
  type        = string
  validation {
    condition     = can(regex("^(dev|tst|acc|prd)$", var.dtap_environment))
    error_message = "DTAP environment must be one of dev, tst, acc, prd"
  }
}

variable "container_log_v2_enabled" {
  description = "Enable ContainerLogV2 collection for the AKS cluster."
  type        = bool
  default     = true
}

variable "aks_nodepools_config" {
  description = "A map of node pools to create in the AKS cluster"
  type = map(object({
    vm_size                = optional(string)
    min_count              = optional(number)
    max_count              = optional(number)
    enable_auto_scaling    = optional(bool)
    enable_host_encryption = optional(bool)
    max_pods               = optional(number)
    os_disk_type           = optional(string)
  }))
  default = {
    pool001 = {
      vm_size                = "Standard_d4ds_v5"
      min_count              = 3
      max_count              = 5
      enable_auto_scaling    = false
      enable_host_encryption = true
      max_pods               = 50
      os_disk_type           = "Managed"
    },
  }
}

variable "aks_nodepools_upgrade_settings" {
  description = "A map of upgrade settings for the AKS cluster"
  type = object({
    drain_timeout_in_minutes      = optional(number)
    max_surge                     = optional(string)
    node_soak_duration_in_minutes = optional(number)
  })
  default = {
    drain_timeout_in_minutes      = 30
    max_surge                     = "1"
    node_soak_duration_in_minutes = 0
  }
}
variable "aks_system_nodes_config" {
  description = "The system node pool configuration"
  type = object({
    vm_size                      = optional(string)
    min_count                    = optional(number)
    max_count                    = optional(number)
    enable_auto_scaling          = optional(bool)
    enable_host_encryption       = optional(bool)
    max_pods                     = optional(number)
    only_critical_addons_enabled = optional(bool)
    os_disk_type                 = optional(string)
  })
  default = {
    vm_size                      = "Standard_d4ds_v5"
    min_count                    = 3
    max_count                    = 5  
    enable_auto_scaling          = true
    enable_host_encryption       = true
    max_pods                     = 50
    only_critical_addons_enabled = true
    os_disk_type                 = "Managed"
  }
}

variable "aks_system_nodes_upgrade_settings" {
  description = "The system node pool upgrade settings"
  type = object({
    drain_timeout_in_minutes      = optional(number)
    max_surge                     = optional(string)
    node_soak_duration_in_minutes = optional(number)
  })
  default = {
    drain_timeout_in_minutes      = 30
    max_surge                     = 1
    node_soak_duration_in_minutes = 0
  }
}

