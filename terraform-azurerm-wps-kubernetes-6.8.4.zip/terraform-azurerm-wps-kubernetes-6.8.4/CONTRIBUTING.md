# Contributing

The goal of the Azure Cloud Foundation working group is to collect, document, and publish the Azure Cloud Foundation deployment code. To make the best practices easy to comprehend, evaluate, and apply. More info on the working group can be found in our [README.md](https://github.com/InnerSourceCommons/InnerSourcePatterns/blob/main/README.md) file.

For this working group to thrive, we welcome your contribution - be it small or huge.

## How to Contribute?

Please consider contributing to the Azure Cloud Foundation Patterns. Here some suggestions on how you can contribute.

1. **Share your thoughts & spark discussion**: A fresh perspective, an interesting thought, or an early novel idea can spark discussions and yield unforeseeable results. We invite you to share your thoughts any time by [creating an issue](./issues/new) , [via teams]([Join conversation](https://teams.microsoft.com/l/channel/19%3aHRCwYvGwlFe4aZnFBN1HrtyDMeoA4EWJ3UWaV0sv1_M1%40thread.tacv2/General?groupId=3f928744-d54f-4016-abb0-c95245c690d6&tenantId=76a2ae5a-9f00-4f6b-95ed-5d33d77c4d61)) or [via discord](to be created).

2. **Read & improve existing patterns**: If you want to get started, we encourage you to read through the existing patterns and materials in this repository. Found a misleading phrase or phony grammar? A mistake in the content? Let us know by [creating an issue](https://github.com/InnerSourceCommons/InnerSourcePatterns/issues/new) or directly propose your fix as a pull request.

3. **Review open pull requests**: Even without knowing all the specifics of the patterns working group, your feedback on existing [pull requests](https://github.com/InnerSourceCommons/InnerSourcePatterns/labels/type%20-%20Content%20work) (especially those proposing changes to pattern contents) will be valuable to its authors: As somebody who wants to give input from the perspective of a future reader. 

4. **Be a advocate**: The patterns will become better and cover more topics the more people contribute their perspective and experience. A colleague told you about a novel best practice? Please invite her/him to contribute to this repository!

## [How to get in touch?](https://github.com/InnerSourceCommons/InnerSourcePatterns/blob/main/CONTRIBUTING.md#how-to-get-in-touch)

We are happy to support you in contributing to the patterns or to just chat with you.

You can best reach out to us **via Teams**:

Join the Azure Foundation [Teams Site](https://teams.microsoft.com/l/team/19%3aHRCwYvGwlFe4aZnFBN1HrtyDMeoA4EWJ3UWaV0sv1_M1%40thread.tacv2/conversations?groupId=3f928744-d54f-4016-abb0-c95245c690d6&tenantId=76a2ae5a-9f00-4f6b-95ed-5d33d77c4d61) and enter the `#general` channel there.

## License of Contributions

The contents of this repository are licensed under [TO DEFINE](https://github.com/InnerSourceCommons/InnerSourcePatterns/blob/main/LICENSE.txt). By contributing to this repository, you grant us (and everyone else for that matter) the right to use your contribution in accordance with that license.

## Acknowledgment of Contributions

If you list yourself as the author of a pattern, we assume we have your permission to mention you when referring to the respective pattern.

## Code of Conduct

We expect all contributors to treat each other respectfully and help us to keep this community free of harassment and discrimination. Our complete Contributor Covenant Code of Conduct can be read [here](CODE OF CONDUCT.md)
