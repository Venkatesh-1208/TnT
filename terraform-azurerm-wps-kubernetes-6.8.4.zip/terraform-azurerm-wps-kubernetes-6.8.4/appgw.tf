
# Create user assigned Identity, necessary when using private dns zones and aks
resource "azurerm_user_assigned_identity" "appgw_user_assigned_identity" {
  resource_group_name = var.resource_group_name == null ? azurerm_resource_group.aks_resources[0].name : var.resource_group_name
  location            = var.location
  name                = local.appgw_managed_identity_name

  tags = local.tags
}

# Assign the User Assigned Identity access to the Key Vault
resource "azurerm_role_assignment" "role_assignment_certificates_appgw" {
  scope                = try(azurerm_key_vault.keyvault[0].id, var.key_vault_id)
  role_definition_name = "Key Vault Certificates Officer"
  principal_id         = azurerm_user_assigned_identity.appgw_user_assigned_identity.principal_id
}

resource "azurerm_role_assignment" "role_assignment_secrets_appgw" {
  scope                = try(azurerm_key_vault.keyvault[0].id, var.key_vault_id)
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azurerm_user_assigned_identity.appgw_user_assigned_identity.principal_id
}

#create default WAF policy for AKS application Gateway
resource "azurerm_web_application_firewall_policy" "wafpolicy-default-aks" {
  #checkov:skip=CKV_AZURE_135: "Ensure Application Gateway WAF prevents message lookup in Log4j2. See CVE-2021-44228 aka log4jshell"
  # This rule '944240' is enabled in the default WAF policy
  name                = "waf-default-appgw-${var.fullname}-001"
  resource_group_name = var.resource_group_name == null ? azurerm_resource_group.aks_resources[0].name : var.resource_group_name
  location            = var.location

  policy_settings {
    enabled                          = var.appgw_waf_policy_settings.enabled
    mode                             = var.appgw_waf_policy_settings.mode
    request_body_check               = var.appgw_waf_policy_settings.request_body_check
    request_body_enforcement         = var.appgw_waf_policy_settings.request_body_enforcement
    file_upload_limit_in_mb          = var.appgw_waf_policy_settings.file_upload_limit_in_mb
    max_request_body_size_in_kb      = var.appgw_waf_policy_settings.max_request_body_size_in_kb
    request_body_inspect_limit_in_kb = var.appgw_waf_policy_settings.request_body_inspect_limit_in_kb
  }

  managed_rules {
    managed_rule_set {
      type    = var.appgw_waf_managed_rules.managed_rule_set.type
      version = var.appgw_waf_managed_rules.managed_rule_set.version

      dynamic "rule_group_override" {
        for_each = var.appgw_waf_managed_rules.managed_rule_set.rule_group_overrides != {} && length(var.appgw_waf_managed_rules.managed_rule_set.rule_group_overrides) > 0 ? var.appgw_waf_managed_rules.managed_rule_set.rule_group_overrides : []
        content {
          rule_group_name = rule_group_override.value.rule_group_name
          dynamic "rule" {
            for_each = rule_group_override.value.rules != {} && length(rule_group_override.value.rules) > 0 ? rule_group_override.value.rules : []
            content {
              id      = rule.value.rule_id
              enabled = rule.value.enabled
            }
          }
        }
      }
    }

    dynamic "exclusion" {
      for_each = var.appgw_waf_managed_rules.managed_rule_set.exclusions != null && length(var.appgw_waf_managed_rules.managed_rule_set.exclusions) > 0 ? var.appgw_waf_managed_rules.managed_rule_set.exclusions : []
      content {
        match_variable          = exclusion.value.match_variable
        selector                = try(exclusion.value.selector, null)
        selector_match_operator = try(exclusion.value.selector_match_operator, null)

        dynamic "excluded_rule_set" {
          for_each = exclusion.value.excluded_rule_set != null ? [exclusion.value.excluded_rule_set] : []
          content {
            type    = excluded_rule_set.value.type
            version = excluded_rule_set.value.version

            dynamic "rule_group" {
              for_each = excluded_rule_set.value.rule_group != null ? [excluded_rule_set.value.rule_group] : []
              content {
                rule_group_name = rule_group.value.rule_group_name
                excluded_rules  = rule_group.value.excluded_rules
              }
            }
          }
        }
      }
    }
  }

  dynamic "custom_rules" {
    for_each = var.appgw_waf_custom_rules != {} && length(var.appgw_waf_custom_rules.custom_rules) > 0 ? var.appgw_waf_custom_rules.custom_rules : []
    content {
      enabled   = custom_rules.value.enabled
      name      = custom_rules.value.name
      priority  = custom_rules.value.priority
      rule_type = custom_rules.value.rule_type
      action    = custom_rules.value.action

      dynamic "match_conditions" {
        for_each = custom_rules.value.match_conditions
        content {
          match_values       = match_conditions.value.match_values
          operator           = match_conditions.value.operator
          negation_condition = match_conditions.value.negation_condition
          transforms         = match_conditions.value.transforms

          dynamic "match_variables" {
            for_each = match_conditions.value.match_variables
            content {
              variable_name = match_variables.value.variable_name
              selector      = match_variables.value.selector
            }
          }
        }
      }
    }
  }

  tags = local.tags
}

resource "azurerm_public_ip" "appgw_pip" {
  name                = "pip-appgw-${var.fullname}-001"
  resource_group_name = var.resource_group_name == null ? azurerm_resource_group.aks_resources[0].name : var.resource_group_name
  location            = var.location
  allocation_method   = "Static"
  sku                 = "Standard"
  sku_tier            = "Regional"
  zones               = var.availability_zones
  domain_name_label   = var.domain_name_label

  tags = local.tags
}

# Generate certificate to be used with application gateway
resource "azurerm_key_vault_certificate" "appgw_cert" {
  depends_on = [
    azurerm_role_assignment.role_assignment_certificates_appgw,
    azurerm_role_assignment.role_assignment_secrets_appgw,
    azurerm_user_assigned_identity.appgw_user_assigned_identity,
    azurerm_key_vault.keyvault,
    azurerm_role_assignment.role_assignments_current_user
  ]
  name         = local.appgw_name
  key_vault_id = try(azurerm_key_vault.keyvault[0].id, var.key_vault_id)

  certificate_policy {
    issuer_parameters {
      name = "Self"
    }

    key_properties {
      exportable = true
      key_size   = 2048
      key_type   = "RSA"
      reuse_key  = true
    }

    lifetime_action {
      action {
        action_type = "AutoRenew"
      }

      trigger {
        days_before_expiry = 30
      }
    }

    secret_properties {
      content_type = "application/x-pkcs12"
    }

    x509_certificate_properties {
      extended_key_usage = ["1.3.6.1.5.5.7.3.1"]

      key_usage = [
        "cRLSign",
        "dataEncipherment",
        "digitalSignature",
        "keyAgreement",
        "keyCertSign",
        "keyEncipherment",
      ]

      subject_alternative_names {
        dns_names = [local.appgw_name_fqdn]
      }

      subject            = "CN=${local.appgw_name}"
      validity_in_months = 12
    }
  }
  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_application_gateway" "appgw" {
  depends_on = [
    azurerm_role_assignment.role_assignment_certificates_appgw,
    azurerm_role_assignment.role_assignment_secrets_appgw,
    azurerm_web_application_firewall_policy.wafpolicy-default-aks
  ]
  name                = local.appgw_name
  resource_group_name = var.resource_group_name == null ? azurerm_resource_group.aks_resources[0].name : var.resource_group_name
  location            = var.location
  zones               = var.availability_zones != null ? var.availability_zones : null
  #Assign default WAF policy to default listener
  force_firewall_policy_association = true
  firewall_policy_id                = azurerm_web_application_firewall_policy.wafpolicy-default-aks.id
  lifecycle { # necessary because we configure the application gateway through kubectl
    ignore_changes = [
      backend_address_pool,
      backend_http_settings,
      http_listener,
      request_routing_rule,
      redirect_configuration,
      url_path_map,
      probe,
      frontend_port,
      global,
      tags,
      ssl_certificate,
      trusted_root_certificate
    ]
  }

  identity {
    type = "UserAssigned"
    identity_ids = [
      azurerm_user_assigned_identity.appgw_user_assigned_identity.id
    ]
  }

  sku {
    name = var.appgw_sku.name
    tier = var.appgw_sku.tier
  }

  ssl_certificate {
    name                = local.appgw_name
    key_vault_secret_id = azurerm_key_vault_certificate.appgw_cert.secret_id
  }

  dynamic "ssl_certificate" {
    for_each = var.appgw_ssl_certificates
    content {
      name                = ssl_certificate.value.name
      key_vault_secret_id = replace(ssl_certificate.value.key_vault_secret_id, "certificates", "secrets")
    }
  }

  dynamic "trusted_root_certificate" {
    for_each = var.appgw_trusted_root_certificates
    content {
      name                = trusted_root_certificate.value.name
      key_vault_secret_id = replace(trusted_root_certificate.value.key_vault_secret_id, "certificates", "secrets")
    }
  }

  backend_address_pool {
    name = "default_bep-${local.appgw_name}"
  }

  backend_http_settings {
    name                  = "bep-default-${local.appgw_name}"
    cookie_based_affinity = var.appgw_backend_http_settings.cookie_based_affinity
    port                  = var.appgw_backend_http_settings.port
    protocol              = var.appgw_backend_http_settings.protocol
    request_timeout       = var.appgw_backend_http_settings.request_timeout
  }

  frontend_ip_configuration {
    name                 = "Public"
    public_ip_address_id = azurerm_public_ip.appgw_pip.id
  }

  frontend_ip_configuration {
    name                          = "Private"
    private_ip_address            = var.appgw_private_ip_address
    private_ip_address_allocation = "Static"
    subnet_id                     = var.appgw_subnet_id
  }

  frontend_port {
    name = "frontend-port-${local.appgw_name}"
    port = 443
  }

  gateway_ip_configuration {
    name      = "ip-configuration-${local.appgw_name}"
    subnet_id = var.appgw_subnet_id
  }

  http_listener {
    name                           = "listener-default-${local.appgw_name}"
    frontend_ip_configuration_name = "Private"
    frontend_port_name             = "frontend-port-${local.appgw_name}"
    protocol                       = "Https"
    host_name                      = local.appgw_name
    ssl_certificate_name           = local.appgw_name
  }

  ssl_policy {
    policy_type          = var.appgw_ssl_policy.policy_type
    cipher_suites        = var.appgw_ssl_policy.cipher_suites
    min_protocol_version = var.appgw_ssl_policy.min_protocol_version
  }

  request_routing_rule {
    name                       = "default-rule-${local.appgw_name}"
    rule_type                  = var.appgw_request_routing_rule.rule_type
    http_listener_name         = "listener-default-${local.appgw_name}"
    backend_address_pool_name  = "default_bep-${local.appgw_name}"
    backend_http_settings_name = "bep-default-${local.appgw_name}"
    priority                   = var.appgw_request_routing_rule.priority
  }

  autoscale_configuration {
    min_capacity = var.appgw_auto_scaling.min_capacity
    max_capacity = var.appgw_auto_scaling.max_capacity
  }

  enable_http2 = var.appgw_enable_http2

  tags = local.tags
}

resource "azurerm_monitor_diagnostic_setting" "appgw" {
  name                       = "appgw-logging"
  log_analytics_workspace_id = try(azurerm_log_analytics_workspace.law_aks[0].id, var.law_id)
  target_resource_id         = azurerm_application_gateway.appgw.id
  enabled_log {
    category_group = "allLogs"
  }

  enabled_metric {
    category = "AllMetrics"
  }
}
