data "azurerm_role_definition" "roles" {
  for_each = local.group_role_assignments
  name     = each.value
}

resource "time_static" "kv_pim_time" {
  count = var.pim_enabled ? 1 : 0
}
resource "azurerm_pim_eligible_role_assignment" "group_assignments" {
  for_each = var.pim_enabled ? local.valid_group_assignments : {}

  scope              = local.scope_mappings[each.key]
  role_definition_id = "${local.scope_subscription_mappings[each.key]}${data.azurerm_role_definition.roles[each.key].id}"
  principal_id       = local.group_mappings[each.key]

  schedule {
    start_date_time = time_static.kv_pim_time[0].rfc3339
    expiration {
      duration_days = var.pim_policy.duration_days
    }
  }

  justification = "PIM eligible assignment for ${each.value}"
}

resource "azurerm_role_management_policy" "group_policies" {
  for_each = var.pim_enabled ? local.valid_group_assignments : {}

  scope              = local.scope_mappings[each.key]
  role_definition_id = data.azurerm_role_definition.roles[each.key].id

  active_assignment_rules {
    expire_after = var.pim_policy.active_assignment_rules.expire_after
  }

  eligible_assignment_rules {
    expiration_required = var.pim_policy.eligible_assignment_rules.expiration_required
  }

  activation_rules {
    maximum_duration = var.pim_policy.activation_rules.maximum_duration
    require_approval = var.pim_policy.activation_rules.require_approval
    require_justification = var.pim_policy.activation_rules.require_justification
    approval_stage {
      primary_approver {
        object_id = local.group_mappings[each.key]
        type      = var.pim_policy.activation_rules.approval_stage.primary_approver.type
      }
    }
  }
}

