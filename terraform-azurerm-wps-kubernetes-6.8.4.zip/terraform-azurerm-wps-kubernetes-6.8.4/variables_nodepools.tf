variable "aks_nodepools_config" {
  description = "A map of node pools to create in the AKS cluster"
  type = map(object({
    name                   = optional(string)
    vm_size                = optional(string)
    min_count              = optional(number)
    max_count              = optional(number)
    enable_auto_scaling    = optional(bool)
    gpu_driver             = optional(string)
    enable_host_encryption = optional(bool)
    max_pods               = optional(number)
    os_disk_type           = optional(string)
    node_labels            = optional(map(string))
    node_taints            = optional(list(string))
    scale_down_mode        = optional(string)
    os_type                = optional(string)
    os_sku                 = optional(string)
    outbound_nat_enabled   = optional(bool) 
  }))
  default = {
    pool001 = {
      name                   = "pool001"
      vm_size                = "Standard_d4ds_v5"
      min_count              = 2
      max_count              = 4
      enable_auto_scaling    = true
      enable_host_encryption = true
      max_pods               = 50
      os_disk_type           = "Managed"
      node_labels            = {}
      node_taints            = []
      scale_down_mode        = "Delete"
      os_type                = "Linux"
      os_sku                 = "Ubuntu"
    }
  }
}

variable "aks_nodepools_upgrade_settings" {
  description = "A map of upgrade settings for the AKS cluster"
  type = object({
    drain_timeout_in_minutes      = optional(number)
    max_surge                     = optional(string)
    node_soak_duration_in_minutes = optional(number)
  })
  default = {
    drain_timeout_in_minutes      = 30
    max_surge                     = "1"
    node_soak_duration_in_minutes = 0
  }
}
