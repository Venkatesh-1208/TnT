# Azure Kubernetes Service (AKS)

Azure Kubernetes Service (AKS) is a managed Kubernetes service that you can use to deploy and manage containerized applications. You need minimal container orchestration expertise to use AKS. AKS reduces the complexity and operational overhead of managing Kubernetes by offloading much of that responsibility to Azure. AKS is an ideal platform for deploying and managing containerized applications that require high availability, scalability, and portability, and for deploying applications to multiple regions, using open-source tools, and integrating with existing DevOps tools.

Overview of AKS
AKS reduces the complexity and operational overhead of managing Kubernetes by shifting that responsibility to Azure. When you create an AKS cluster, Azure automatically creates and configures a control plane for you at no cost. The Azure platform manages the AKS control plane, which is responsible for the Kubernetes objects and worker nodes that you deploy to run your applications. Azure takes care of critical operations like health monitoring and maintenance, and you only pay for the AKS nodes that run your applications.

AKS overview graphic

![AKS Overview](what-is-aks.png)

!!! Note

    AKS is CNCF-certified and is compliant with SOC, ISO, PCI DSS, and HIPAA. For more information, see the Microsoft Azure compliance overview.

## Features of AKS

Identity and security management

* Enforce regulatory compliance controls using Azure Policy with built-in guardrails and internet security benchmarks.
* Integrate with Kubernetes RBAC to limit access to cluster resources.
* Use Microsoft Entra ID to set up Kubernetes access based on existing identity and group membership.

Logging and monitoring

* Integrate with Container Insights, a feature in Azure Monitor, to monitor the health and performance of your clusters and containerized applications.
* Set up Network Observability to collect and visualize network traffic data from your clusters.
* Ability to integrate with managed prometheus (WIP)

Streamlined deployments

* Use prebuilt cluster configurations for Kubernetes with smart defaults.
* Autoscale your applications using the Kubernetes Event Driven Autoscaler (KEDA).
* Use Draft for AKS to ready source code and prepare your applications for production.

Clusters and nodes

* Connect storage to nodes and pods, upgrade cluster components, and use GPUs.
* Create clusters that run multiple node pools to support mixed operating systems and Windows Server containers.
* Configure automatic scaling using the cluster autoscaler and horizontal pod autoscaler.
* Deploy clusters with confidential computing nodes to allow containers to run in a hardware-based trusted execution environment.

Storage volume support

* Mount static or dynamic storage volumes for persistent data.
* Use Azure Disks for single pod access and Azure Files for multiple, concurrent pod access.
* Use Azure NetApp Files for high-performance, high-throughput, and low-latency file shares.

Networking

* Leverage our networking options for your needs.
* Bring your own Container Network Interface (CNI) to use a third-party CNI plugin.
* Easily access applications deployed to your clusters using the application routing add-on with nginx.

Development tooling integration

* Develop on AKS with Helm.
* Install the Kubernetes extension for Visual Studio Code to manage your workloads.
* Leverage the features of Istio with the Istio-based service mesh add-on.

## Resources that will be created

When using this AKS module with the only the required parameters provided, the following resources will be created:

* An Azure Container Registry (ACR) with a private endpoint in the provided subnet and replication to a failover region enabled. The ACR will only be created when no value is provided for the `acr_existing_acr_name` parameter.
* An application gateway connected to the AKS cluster.
* A default WAF policy for the application gateway, connected to teh application gateway.
* Four Entra ID groups for providing access to the AKS cluster (RBAC Admin, RBAC Cluster Admin, RBAC Reader and RBAC Writer)
* Twelve Entra ID groups for the Key Vault resource (Administrator, Certificate User, Certificates Officer, Contributor, Crypto Officer, Crypto Service Encryption User, Crypto Service Release User, Crypto User, Data Access Administrator, Reader, Secrets Officer, Secrets User)
* Six Entra ID groups for the Azure Container Registry (AcrDelete, AcrImageSigner, AcrPull, AcrPush, AcrQuarantineReader, AcrQuarantineWriter)
* A Log Analytics Workspace where the deployed resources are connected to. The Log Analytics Gateway will only be created when no value is provided for the `log_analytics_workspace_id` parameter.
* An AKS cluster with a system node pool and one workload node pool.
* Managed identities for both the AKS cluster and the application gateway.

!!! Note
    The AKS cluster will use Entra ID Authentication with Azure RBAC for Kubernetes Authorization.

## Usage

### Private endpoint

Below an example for deploying an Azure Database for PostgreSQL flexible server with a private endpoint

```terraform
module "aks" {
  source                       = ""git::ssh://git@ssh.dev.azure.com/v3/ORGANIZATION/PROJECT/terraform-azurerm-wps-kubernetes"
  version                      = "1.0.0"

  fullname  = "cf-app-prd-euw-${random_string.random[0].result}"
  shortname = "cfappprdeuw${random_string.random[0].result}"

  location                    = "westeurope"
  
  acr_georeplication_location = "northeurope"
  
  aks_dns_id = azurerm_private_dns_zone.dns_aks.id
  aks_number_of_node_pools = 1
  aks_system_nodes_subnet_ids   = [azurerm_subnet.aks_system_nodes.id]
  aks_system_pods_subnet_ids   = [azurerm_subnet.aks_system_pods.id]
  aks_version              = "1.30.0"
  aks_vnet_id                 = azurerm_virtual_network.vnet.id
  aks_workload_subnet_ids      = [azurerm_subnet.aks_workload_nodes.id]
  aks_workload_pods_subnet_ids = [azurerm_subnet.aks_workload_pods.id]
  
  appgw_subnet_id              = azurerm_subnet.aks_appgw_range.id
  appgw_private_ip_address     = "172.20.30.10"

  key_vault_id = azurerm_key_vault.aks_key_vault.id

  private_endpoint_subnet_id   = azurerm_subnet.aks_private_endpoints.id
  
  mandatory_tags = {
    ApplicationName      = "YourAppName"
    ApproverContact      = "ApproverContactValue"
    BusinessContact      = "BusinessContactValue"
    BusinessLevel        = "BusinessLevelValue"
    BusinessUnit         = "BusinessUnitValue"
    CostCentre           = "CostCentreValue"
    DataClassification   = "DataClassificationValue"
    DisasterRecovery     = "DisasterRecoveryValue"
    Environment          = "EnvironmentValue"
    OperationsCommitment = "OperationsCommitmentValue"
    OperationsContact    = "OperationsContactValue"
    OrgCode              = "OrgCodeValue"
    ServiceClass         = "ServiceClassValue"
    SolutionGroup        = "SolutionGroupValue"
    WorkloadName         = "WorkloadNameValue"
  }

}
```

### PIM Assignment

To use PIM assignment within this module change the parameter pim_enabled from false to true

Example below

```terraform
module "aks" {
  depends_on = [
    azurerm_firewall.fw_aks,
    azurerm_private_dns_zone.dns_acr,
    azurerm_private_dns_zone.dns_aks
  ]
  source = "../"

  fullname  = "cf-app-prd-euw-${random_string.random[0].result}"
  shortname = "cfappprdeuw${random_string.random[0].result}"

  location                    = "westeurope"
  acr_georeplication_location = "northeurope"
  aks_vnet_id                 = azurerm_virtual_network.vnet.id

  aks_system_nodes_subnet_ids   = [azurerm_subnet.aks_system_nodes.id]
  aks_system_pods_subnet_ids   = [azurerm_subnet.aks_system_pods.id]
  aks_workload_subnet_ids      = [azurerm_subnet.aks_workload_nodes.id]
  aks_workload_pods_subnet_ids = [azurerm_subnet.aks_workload_pods.id]
  private_endpoint_subnet_id   = azurerm_subnet.aks_private_endpoints.id
  appgw_subnet_id              = azurerm_subnet.aks_appgw_range.id
  appgw_private_ip_address     = "172.20.30.10"

  aks_dns_id = azurerm_private_dns_zone.dns_aks.id

  aks_version              = "1.29"
  aks_number_of_node_pools = 1

  # acr_existing_acr_id = "/subscriptions/1db02c81-075d-4d9c-804d-c3eac16fb1c0/resourceGroups/rg-portal-platform/providers/Microsoft.ContainerRegistry/registries/crcfportalprdeuw001"

  pim_enabled = true

  key_vault_configuration = {
    public_network_access_enabled = true

    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Allow"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
  }
}  
```

<!-- To change the parameters for PIM please change the default parameters in the following variable:

variable "pim_policy" {
  description = "Parameters for the PIM policy"
  type = object({
    duration_days = number
    active_assignment_rules = {
      expire_after = string
    }
    eligible_assignment_rules = optional(object({
      expiration_required = bool
    }))
    activation_rules = optional(object({
      approval_stage = optional(object({
        primary_approver = optional(object({
          type = string
        }))
      }))
      maximum_duration                   = string
      require_approval                   = bool
      require_justification              = bool
      require_multifactor_authentication = bool
    }))
  })

  default = {
    duration_days = 365
    active_assignment_rules = {
      expire_after = "P365D"
    }
    eligible_assignment_rules = {
      expiration_required = false
    }
    activation_rules = {
      approval_stage = {
        primary_approver = {
          type = "Group"
        }
      }
      maximum_duration      = "PT8H" Valid range is PT30M to PT23H30M
      require_approval      = true or false
      require_justification = true or false
    }
  }
}
``` -->

## Required parameters

| Parameter | Description |
| ----- | ----- |
| appgw_private_ip_address | The private IP address of the application gateway. |
| appgw_subnet_id | The id of the subnet for the application gateway. |
| aks_dns_id | The id of the private DNS zone used for AKS. |
| aks_system_pods_subnet_ids | A list of subnet ids for the pods on the system nodes |
| aks_system_nodes_subnet_ids | A list of subnet ids for the system nodes. |
| aks_vnet_id | The id of the VNET where the aks subnets are in. |
| aks_workload_pods_subnet_ids | A list of subnet ids for the pods on the workload nodes |
| aks_workload_subnet_ids | A list of subnet ids for the workload nodes. |
| aks_version | The version of Kubernetes to use for the AKS cluster. |
| fullname | The full name used for naming the resources. |
| key_vault_id | The id of the key vault. |
| mandatory_tags | An object of mandatory tags |
| private_endpoint_subnet_id | The id of the subnet for the private endpoints. |
| shortname | The shortname used for naming the resources. |

## Optional parameters

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| acr_admin_enabled | Specify if admin access should be enabled. | false |
| acr_existing_acr_id | The id of the existing ACR to be used. | null |
| acr_export_policy_enabled | Enable export policy for the ACR. | false |
| acr_georeplication_location | The location of the georeplication. | norhteurope |
| acr_public_network_access_enabled | Enable public network access to the ACR. | false |
| acr_quarantine_policy_enabled | Enable quarantine policy for the ACR. | true |
| acr_retention_policy_days | The number of days to retain and untagged manifest after which it gets purged. | 31 days retention |
| acr_sku | The sku to be used for the ACR. | Premium |
| acr_trust_policy_enabled | Enable trust policy for the ACR. | false |
| acr_zone_redundancy_enabled | Enable zone redundancy for the ACR. | true |
| appgw_auto_scaling | An `appgw_auto_scaling` block as described below | |
| appgw_backend_http_settings | An `appgw_backend_http_settings` block as described below | |
| appgw_waf_custom_rules | An `appgw_waf_custom_rules` block as described below | [] |
| appgw_dns_zone_name | The name of the DNS zone used for the SAN name of the certificate for the application gateway. | nodomain.local |
| appgw_enable_http2 | Enable HTTP2. | true |
| appgw_request_routing_rule | An `appgw_request_routing_rule` block as described below | |
| appgw_ssl_certificates | An `appgw_ssl_certificates` block as described below | [] |
| appgw_ssl_policy | An `appgw_ssl_policy` block as described below. The default values support TLS 1.2 and TLS 1.3. | |
| appgw_trusted_root_certificates | An `appgw_trusted_root_certificates` block as described below | [] |
| appgw_waf_managed_rules | An `appgw_waf_managed_rules` block as described below | [] |
| appgw_sku | The SKU of the application gateway. | name = "WAF_v2", tier = "WAF_v2" |
| appgw_waf_policy_settings | An `appgw_waf_policy_settings` block as described below | |
| aks_active_directory_role_based_access_control | The Azure Active Directory role based access control for the AKS cluster | azure_rbac_enabled = true |
| aks_automatic_upgrade_channel | The automatic channel upgrade setting for the AKS cluster. | patch |
| aks_availability_zones | The availability zones for the AKS cluster. | [1,2,3] |
| aks_cost_analysis_enabled | Enable cost analysis for the AKS cluster. | true |
| aks_enable_disk_encryption | Enable disk encryption with CMK for the AKS cluster. | false |
| aks_local_account_disabled | Disable the local account for the AKS cluster. | true |
| aks_network_profile | An `aks_network_profile` block as described below | |
| aks_nodepools_config | An `aks_nodepools_config` block as described below. | |
| aks_nodepools_upgrade_settings | An `aks_nodepools_upgrade_settings` block as described below. | |
| aks_number_of_node_pools | The number of node (workload) pools to create. | 1 |
| aks_private_cluster_enabled | Enable private cluster for the AKS cluster. | true |
| aks_oidc_issuer_enabled | Enable OIDC issuer for the AKS cluster. | true |
| aks_run_command_enabled | Enable run command for the AKS cluster. | false |
| aks_secret_rotation_enabled | Enable secret rotation for the AKS cluster. | true |
| aks_sku_tier | The SKU tier for the AKS cluster. | Standard |
| aks_support_plan | The support plan for the AKS cluster. | KubernetesOfficial |
| aks_storage_profile | An `aks_storage_profile` block as described below | |
| aks_system_nodes_config | An `aks_system_node_config` block as described below. | |
| aks_system_nodes_upgrade_settings | An `aks_system_nodes_upgrade_settings` block as described below. | |
| aks_workload_identity_enabled | Enable workload identity for the AKS cluster. | true |
| aks_azure_policy_enabled | Enable Azure Policy for the AKS cluster. | true |
| container_log_v2_enabled | Flag to enable Azure Monitor ContainerLogV2 schema via Data Collection Rules. | true |
| diagnostic_metrics_enabled | Enable diagnostic metrics. | true |
| group_names | A `group_names` block as specified below. | |
| law_id | The ID of the log analytics workspace. | null |
| law_retention_in_days | The retention in days of the Log Analytics Workspace. | 30 |
| law_sku | The SKU of the Log Analytics Workspace | PerGB2018 |
| location | The region in which to deploy the resources | westeurope |
| pim_enabled | Specify if pim policies will be created | true |
| pim_policy | A `pim_policy` block as described below | |
| optional_tag | An object of optional tags | null |

### appgw_auto_scaling

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| min_capacity | Minimum capacity for autoscaling. Accepted values are in the range 0 to 100. | 1 |
| max_capacity | Maximum capacity for autoscaling. Accepted values are in the range 2 to 125. | 2 |

### appgw_backend_http_settings

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| cookie_based_affinity | Is Cookie-Based Affinity enabled? | Disabled |
| port | he port which should be used for this Backend HTTP Settings Collection. | 80 |
| protocol | The Protocol which should be used. Possible values are Http and Https. | Http |
| request_timeout | The request timeout in seconds, which must be between 1 and 86400 seconds. | 60 |

### appgw_waf_custom_rules

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| custom_rules | A list of objects to specify custom rules for the WAF policy | |

Example:

    custom_rules = [
      {
        name      = "BlockEmptyAPIKey"
        priority  = 1
        rule_type = "MatchRule"
        action    = "Block"

        match_conditions = [{
          match_variables = [{
            variable_name = "RequestHeaders"
            selector      = "apikey"
          }]

          operator           = "Regex"
          match_values       = [".+"]
          negation_condition = true
        }]
      }
    ]

### appgw_request_routing_rule

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| rule_type | The Type of Routing that should be used for this Rule. Possible values are Basic and PathBasedRouting. | Basic |
| priority | Rule evaluation order can be dictated by specifying an integer value from 1 to 20000. | 1000 |

### appgw_ssl_certificates

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| name | A string with the name of the SSL certificate as shown in the application gateway. | |
| key_vault_secret_id | A string with the ID of the certificate in the key vault. ||

Example:

    appgw_ssl_certificates = [
      {
        name                = "mycertificate"
        key_vault_secret_id = "https://kvcfappprdeuw4awoa001.vault.azure.net/certificates/mycertificate"
      },
      {
        name                = "myothercertificate"
        key_vault_secret_id = "https://kvcfappprdeuw4awoa001.vault.azure.net/certificates/myothercertificate/d831f82c43a646ee8ce8870a94c837a5"
      }
    ]

### appgw_ssl_policy

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| policy_type | The Type of the Policy. Possible values are Predefined, Custom and CustomV2. | CustomV2 |
| cipher_suites | The cipher suites used for the SSL policy. | TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256, TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384, TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256, TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 |
| min_protocol_version | The minimal protocol version supported by the SSL Policy. | TLSv1_2 |

### appgw_trusted_root_certificates

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| name | A string with the name of the trusted root certificate as shown in the application gateway. | |
| key_vault_secret_id | A string with the ID of the secret in the key vault. The secret value in the key vault needs to be 64 base encoded. ||

Example:

    appgw_trusted_root_certificates = [
      {
        name                = "myrootca"
        key_vault_secret_id = "https://kvcfappprdeuw4awoa001.vault.azure.net/secrets/myrootca/eea3d7bd861b4c11b24643c2097a5611"
      },
      {
        name                = "myotherrootca"
        key_vault_secret_id = "https://kvcfappprdeuw4awoa001.vault.azure.net/secrets/myotherrootca"
      }
    ]

### appgw_waf_managed_rules

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| managed_rule_set | Specifies the type, version, overrides and exceptions for the managed_rule_set | |

Example:

    managed_rule_set = {
          type    = "OWASP"
          version = "3.2"
          rule_group_overrides = [
            {
              rule_group_name = "REQUEST-920-PROTOCOL-ENFORCEMENT"
              rules = [
                {
                  rule_id = "920320"
                  enabled = false
                },
                {
                  rule_id = "920330"
                  enabled = false
                }
              ]
            },
            {
              rule_group_name = "REQUEST-913-SCANNER-DETECTION"
              rules = [
                {
                  rule_id = "913101"
                  enabled = false
                }
              ]
            }
          ]
          exclusions = [
            {
              match_variable          = "RequestHeaderNames"
              selector                = "x-company-secret-header"
              selector_match_operator = "Equals"
            }
          ]
        }

### appgw_waf_policy_settings

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| enabled | Describes if the policy is in enabled state or disabled state. | true |
| mode | Describes if it is in detection mode or prevention mode at the policy level. | Prevention |
| request_body_check | Is Request Body Inspection enabled. | true |
| request_body_enforcement | Whether the firewall should block a request with body size greater then max_request_body_size_in_kb. | true |
| file_upload_limit_in_mb | The File Upload Limit in MB. Accepted values are in the range 1 to 4000. | 100 |
| max_request_body_size_in_kb | The Maximum Request Body Size in KB. Accepted values are in the range 8 to 2000. | 128 |
| request_body_inspect_limit_in_kb | Specifies the maximum request body inspection limit in KB for the Web Application Firewall. | 128 |

### aks_network_profile

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| network_plugin | Network plugin to use for networking. | azure |
| network_mode | Network mode to be used with Azure CNI. | transparent |
| network_policy | Sets up network policy to be used with Azure CNI. | azure |
| outbound_type | The outbound (egress) routing method which should be used for this Kubernetes Cluster. | userDefinedRouting |
| service_cidr | The Network Range used by the Kubernetes service. | 10.0.0.0/16 |
| dns_service_ip | IP address within the Kubernetes service address range that will be used by cluster service discovery (kube-dns). | 10.0.0.10 |

### aks_nodepools_config

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| name | The name of the Node Pool which should be created within the Kubernetes Cluster | pool001 |
| vm_size | The size of the Virtual Machine | Standard_d4ds_v5 |
| min_count | The minimum number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000. | 3 |
| max_count | The initial number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000 and between min_count and max_count. | 5 |
| enable_auto_scaling | Specifies if autoscaling is enabled. | true |
| enable_host_encryption | Should the nodes in the Default Node Pool have host encryption enabled. | true |
| max_pods | The maximum number of pods that can run on each agent. | 50 |
| os_disk_type | The type of disk which should be used for the Operating System. Possible values are Ephemeral and Managed. | Managed |
| node_labels | A map of Kubernetes labels which should be applied to nodes in this Node Pool. | {} |
| node_taints | A list of Kubernetes taints which should be applied to nodes in the agent pool. | [] |
| os_type | The operating system type for the node pool. Possible values are Linux and Windows. | Linux |
| os_sku | The operating system SKU for the node pool. Possible values include Ubuntu, AzureLinux, CBLMariner, etc. | Ubuntu |
| gpu_driver | **(v6.7.0)** Optional GPU driver type configuration for GPU-enabled node pools (e.g., `"Install"`). | null |
| outbound_nat_enabled | **(v6.8.0)** Optional configuration parameter to toggle host-level outbound Source NAT profile assignments on Windows node pools. | null |


An example for using multiple nodes pools, after setting the variable `aks_number_of_node_pools = 2` can be found in the main.tf file which is located in the .\tests folder within this module.

### aks_nodepools_upgrade_settings

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| drain_timeout_in_minutes | The amount of time in minutes to wait on eviction of pods and graceful termination per node. | 30 |
| max_surge | The maximum number or percentage of nodes which will be added to the Node Pool size during an upgrade. | 1 |
| node_soak_duration_in_minutes | The amount of time in minutes to wait after draining a node and before reimaging and moving on to next node. | 0 |

### aks_storage_profile

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| blob_driver_enabled | Is the Blob CSI driver enabled. | true |
| disk_driver_enabled | Is the Disk CSI driver enabled. | true |

### aks_system_node_config block

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| vm_size | The size of the Virtual Machine | Standard_d4ds_v5 |
| min_count | The minimum number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000. | 3 |
| max_count | The initial number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000 and between min_count and max_count. | 5 |
| enable_auto_scaling | Specifies if autoscaling is enabled. | true |
| enable_host_encryption | Should the nodes in the Default Node Pool have host encryption enabled. | true |
| max_pods | The maximum number of pods that can run on each agent. | 50 |
| only_critical_addons_enabled | Enabling this option will taint default node pool with CriticalAddonsOnly=true:NoSchedule taint. | true |
| os_disk_type | The type of disk which should be used for the Operating System. Possible values are Ephemeral and Managed. | Managed |
| node_labels | A map of Kubernetes labels which should be applied to nodes in this Node Pool. | {} |

### aks_system_nodes_upgrade_settings

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| drain_timeout_in_minutes | The amount of time in minutes to wait on eviction of pods and graceful termination per node. | 30 |
| max_surge | The maximum number or percentage of nodes which will be added to the Node Pool size during an upgrade. | 1 |
| node_soak_duration_in_minutes | The amount of time in minutes to wait after draining a node and before reimaging and moving on to next node. | 0 |

### group_names

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| AzureKubernetesServiceRBACAdmin | The name for the Entra ID group for the RBAC Admin role | null |
| AzureKubernetesServiceRBACClusterAdmin | The name for the Entra ID group for the RBAC  Cluster Admin role | null |
| AzureKubernetesServiceRBACReader | The name for the Entra ID group for the RBAC Reader role | null |
| AzureKubernetesServiceRBACWriter | The name for the Entra ID group for the RBAC Writer role | null |

### pim_policy

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| eligible_assignment_rules | An `eligible_assignment_rules` block as described below. | |
| activation_rules | An `activation_rules` block as described below. | |
| duration_days | Number of days the eligible assignment lasts. | |
| active_assignment_rules.expire_after | ISO8601 duration for active assignment expiration (e.g., "P365D"). | |
| eligible_assignment_rules.expiration_required | Must an assignment have an expiry date. | |
| activation_rules.approval_stage.primary_approver.type | The type of object acting as an approver. | |
| activation_rules.maximum_duration | The maximum length of time an activated role can be valid. | |
| activation_rules.require_approval | Is approval required for activation of the assignment. | |
| activation_rules.require_justification | Is a justification required during activation of the role. | |

### activation_rules

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| approval_stage | An `approval_stage` block as described below. | |
| maximum_duration | The maximum length of time an activated role can be valid, in an ISO8601 Duration format. | "PT8H" |
| require_approval | Is approval required for activation. | true |
| require_justification | Is a justification required during activation of the role. | true |
| require_multifactor_authentication | Is multi-factor authentication required to activate the role. | true |

### eligible_assignment_rules

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| expiration_required | Must an assignment have an expiry date. false allows permanent assignment. | false |

### approval_stage

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| primary_approver | An `primary_approver` block as described below | |

### primary_approver

| Parameter | Description | Default value |
| ----- | ----- | ----- |
| type | The type of object acting as an approver. Possible options are singleUser and groupMembers. | groupMembers |

## Waivers

checkov:skip=CKV_AZURE_164: "Ensures that ACR uses signed/trusted images"
  This settings is optional and default set to false to prevent having to sign all images

checkov:skip=CKV_AZURE_135: "Ensure Application Gateway WAF prevents message lookup in Log4j2. See CVE-2021-44228 aka log4jshell"
  This rule '944240' is enabled in the default WAF policy

checkov:skip=CKV_AZURE_40: "Ensure that the expiration date is set on all keys"
  An expired key for a disk encryption set could cause several issues, so no expiration date has been, making cycling the key a manual action

checkov:skip=CKV_AZURE_112: "Ensure that key vault key is backed by HSM"
  It is not required for the key vault key to be backed by HSM. This is also not determined by the key vault key resource

checkov:skip=CKV_AZURE_226: "Ensure ephemeral disks are used for OS disks"
  It is a design decision to not use ephemeral disks for OS disks

checkov:skip=CKV_AZURE_117: "Ensure that AKS uses disk encryption set"
  Use of disk encryption set is optional

checkov:skip=CKV_AZURE_168: "Ensure Azure Kubernetes Cluster (AKS) nodes should use a minimum number of 50 pods"
  The default value for the max_pods variable is set to 50


---

## Architectural Updates (v6.7.0)

### AKS Log Ingestion Upgrade (ContainerLogV2 Integration)
To optimize log processing pipelines and lower platform costs, the cluster log routing model has been shifted away from traditional extension-based ingestion toward Azure Monitor Data Collection Rules.

* **Change:** Introduced a conditional Data Collection Rule (`azurerm_monitor_data_collection_rule`) and target association (`azurerm_monitor_data_collection_rule_association`) encapsulated inside `dcr.tf`, backed by a feature toggle variable (`container_log_v2_enabled`).
* **Justification:** The legacy `ContainerLog` schema suffers from multi-line log splitting and lacks pod metadata context. Transitioning to the `ContainerLogV2` schema via localized data flows allows the cluster to natively parse multi-line console output, enrich telemetry with Kubernetes namespace/pod metadata, and drop unneeded platform data streams before ingestion.

### Dynamic Node Pool Hardware Acceleration (GPU Driver Provisioning)
To expand cluster processing capabilities for high-performance workloads, the infrastructure pipeline can now dynamically inject vendor-specific hardware dependencies.

* **Change:** Exposed a specialized `gpu_driver` schema attribute inside the overarching `aks_nodepools_config` object map.
* **Justification:** Machine learning and specialized analytics workloads require varied host-level drivers (e.g., NVIDIA) based on the target execution framework. Exposing this configuration at the node pool object level abstracts the management of individual host setups, allowing platform engineers to provision heterogeneous compute clusters using a unified configuration map.

### State Drift Isolation (Application Gateway Lifecycle Updates)
To support diverse application team workflows, high-frequency configuration parameters are isolated from active pipeline delta-checking on the core infrastructure layer.

* **Change:** The **`ssl_certificate`** property block has been appended to the Application Gateway's (`azurerm_application_gateway`) `lifecycle.ignore_changes` array evaluation block.
* **Justification:** Application teams frequently populate and bind custom SSL certificates manually via the Azure Portal or external processes after initial deployment. Previously, this caused continuous state drift and deployment blocking across a large number of downstream application gateway pipelines. Ignoring this attribute allows teams to self-manage certificate lifecycles without triggering unexpected infrastructure destruction or rollbacks during core Terraform execution loops.

---

## Architectural Updates (v6.8.0)

### Windows Outbound NAT State Preservation
To protect critical workloads running on heterogeneous clusters, the core node pool orchestration code has been optimized to handle platform-side default values safely.

* **Change:** Introduced an optional `outbound_nat_enabled` parameter (defaulting to `null`) inside the `aks_nodepools_config` object map schema, backed by a conditional `dynamic "windows_profile"` block tracking `os_type`.
* **Justification:** During AKS upgrades or provider bumps, active Windows node pools were flagged for destructive replacement (`forces replacement`) due to an API valuation drift mismatch. The Azure API assigns a default value of `true` to this setting upon creation. Because the block was missing from the configuration file, the provider interpreted the drift as a request to drop the setting (`true -> null`). Since network profiles are immutable on active hosts, the engine planned a full teardown. Using a native `null` parameter default tells Terraform to treat the attribute as unmanaged, preventing unexpected destruction plans during upgrades while ensuring Linux workloads remain completely unaffected.

## Architectural Updates (v6.8.1)
### [08-09-2026] Dual-OS Telemetry & Safe-Fallback Lookups
- Replaced inner-resource dependencies with direct `var.location` input mapping.
- Implemented an automated ternary switch on `resource_group_name` to bridge internal/external scoping profiles.
- Integrated native Windows logging streams (`Microsoft-ContainerLogV2-Windows`) to handle mixed-OS configurations cleanly.


## Architectural Updates (v6.8.2)
### Unified Data Collection Rules (DCR) for Hybrid Node Pools
To resolve API errors related to invalid payloads (`InvalidPayload: Data collection rule is invalid`), the module handles cluster-wide telemetry using an agnostic Azure Monitor Data Collection Rule configuration. The explicitly defined `kind = "Windows"` and `kind = "Linux"` resource mappings have been removed. 

By omitting the `kind` wrapper property and subscribing explicitly to the consolidated telemetry engine pipeline (`Microsoft-ContainerInsights-Group-Default`), a single rule cleanly spans mixed operational environments. This architectural shift prevents downstream target dependency failures and ensures uniform log scraping via `ContainerLogV2` across disparate Linux and Windows node pools.

