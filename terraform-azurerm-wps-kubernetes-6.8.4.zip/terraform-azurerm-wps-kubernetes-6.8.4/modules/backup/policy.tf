resource "azurerm_data_protection_backup_policy_kubernetes_cluster" "bkp_policy" {
  name                            = "bp-${var.fullname}"
  resource_group_name             = local.resource_group_name
  vault_name                      = azurerm_data_protection_backup_vault.bkp_backup_vault.name
  backup_repeating_time_intervals = [local.backup_repeating_time_interval]

  default_retention_rule {
    life_cycle {
      duration        = var.aks_backup_policy_configuration.daily_retention_duration
      data_store_type = var.aks_backup_vault_configuration.datastore_type
    }
  }

  dynamic "retention_rule" {
    for_each = var.enable_weekly_retention ? [1] : []
    content {
      name     = "Weekly"
      priority = 25

      criteria {
        absolute_criteria = var.aks_backup_policy_configuration.backup_weekly_time
      }

      life_cycle {
        duration        = var.aks_backup_policy_configuration.weekly_retention_duration
        data_store_type = var.aks_backup_vault_configuration.datastore_type
      }
    }
  }
}
