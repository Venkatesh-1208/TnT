resource "azurerm_role_assignment" "bkp_role_assignments" {
  for_each = merge(
    {
      ara1 = {
        scope        = var.aks_id
        role         = "Reader"
        principal_id = azurerm_data_protection_backup_vault.bkp_backup_vault.identity[0].principal_id
      }
      ara2 = {
        scope        = var.aks_rg_id
        role         = "Reader"
        principal_id = azurerm_data_protection_backup_vault.bkp_backup_vault.identity[0].principal_id
      }
      ara3 = {
        scope        = var.aks_rg_id
        role         = "Contributor"
        principal_id = var.aks_principal_id
      }
      ara4 = {
        scope        = var.aks_backup_storage_account_id
        role         = "Storage Blob Data Contributor"
        principal_id = azurerm_kubernetes_cluster_extension.bkp_extension.aks_assigned_identity[0].principal_id
      }
      ara5 = {
        scope        = var.aks_rg_id
        role         = "Data Operator for Managed Disks"
        principal_id = azurerm_data_protection_backup_vault.bkp_backup_vault.identity[0].principal_id
      }
      ara6 = {
        scope        = var.aks_rg_id
        role         = "Disk Snapshot Contributor"
        principal_id = azurerm_data_protection_backup_vault.bkp_backup_vault.identity[0].principal_id
      }
      ara7 = {
        scope        = var.aks_backup_storage_account_id
        role         = "Storage Blob Data Reader"
        principal_id = azurerm_data_protection_backup_vault.bkp_backup_vault.identity[0].principal_id
      }
    },
    var.aks_backup_vault_configuration.datastore_type == "VaultStore" ? {
      ara8 = {
        scope        = var.aks_rg_id
        role         = "Contributor"
        principal_id = azurerm_data_protection_backup_vault.bkp_backup_vault.identity[0].principal_id
      }
      ara9 = {
        scope        = var.aks_backup_storage_account_id
        role         = "Storage Account Contributor"
        principal_id = azurerm_data_protection_backup_vault.bkp_backup_vault.identity[0].principal_id
      }
      ara10 = {
        scope        = var.aks_backup_storage_account_id
        role         = "Storage Blob Data Owner"
        principal_id = azurerm_data_protection_backup_vault.bkp_backup_vault.identity[0].principal_id
      }
    } : {}
  )

  scope                = each.value.scope
  role_definition_name = each.value.role
  principal_id         = each.value.principal_id
}

resource "time_sleep" "wait_for_rbac_propagation" {
  depends_on = [azurerm_role_assignment.bkp_role_assignments]

  create_duration = "180s"
}
