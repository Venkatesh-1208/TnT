resource "azurerm_monitor_action_group" "bkp_ag_alerts" {
  name                = "ag-bkp-${var.fullname}"
  resource_group_name = local.resource_group_name
  short_name          = "BackupAlrt"

  tags = local.tags
}

resource "azurerm_monitor_metric_alert" "bkp_backup_alert" {
  name                = "backup-alert"
  resource_group_name = local.resource_group_name
  scopes              = [azurerm_data_protection_backup_vault.bkp_backup_vault.id]
  description         = "Alert when backup failed"
  severity            = 2
  frequency           = "PT5M"
  window_size         = "PT5M"
  auto_mitigate       = false
  enabled             = true

  criteria {
    metric_namespace = "Microsoft.DataProtection/backupVaults"
    metric_name      = "BackupHealthEvent"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

    dimension {
      name     = "healthStatus"
      operator = "Exclude"
      values   = ["Healthy"]
    }
  }

  action {
    action_group_id = azurerm_monitor_action_group.bkp_ag_alerts.id
  }

  tags = local.tags
}

resource "azurerm_monitor_metric_alert" "bkp_restore_alert" {
  name                = "restore-alert"
  resource_group_name = local.resource_group_name
  scopes              = [azurerm_data_protection_backup_vault.bkp_backup_vault.id]
  description         = "Alert when restore failed"
  severity            = 2
  frequency           = "PT5M"
  window_size         = "PT5M"
  auto_mitigate       = false
  enabled             = true

  criteria {
    metric_namespace = "Microsoft.DataProtection/backupVaults"
    metric_name      = "RestoreHealthEvent"
    aggregation      = "Count"
    operator         = "GreaterThan"
    threshold        = 0

    dimension {
      name     = "healthStatus"
      operator = "Exclude"
      values   = ["Healthy"]
    }
  }

  action {
    action_group_id = azurerm_monitor_action_group.bkp_ag_alerts.id
  }

  tags = local.tags
}
