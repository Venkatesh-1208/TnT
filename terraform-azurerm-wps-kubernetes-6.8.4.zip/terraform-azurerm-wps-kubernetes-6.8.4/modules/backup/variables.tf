variable "fullname" {
  type        = string
  description = "Fullname for the resources."
}

variable "mandatory_tags" {
  description = "mandatory_tags"
  type        = any
}

variable "location" {
  description = "Location to provision resources in."
  type        = string
  default     = "westeurope"
}

variable "aks_principal_id" {
  description = "The managed identity object ID of the AKS Cluster"
  type        = string
}

variable "aks_id" {
  description = "The ID of the AKS cluster"
  type        = string
}

variable "aks_rg_id" {
  type        = string
  description = "The ID of the aks resource group, to use if not using the default."
  default     = null
}

variable "enable_weekly_retention" {
  description = "Enable weekly retention"
  type        = bool
  default     = true
}

variable "optional_tags" {
  description = "optional_tags"
  type        = any
  default     = null
}

variable "aks_backup_storage_account_id" {
  type        = string
  description = "The configuration of the pre-existing backup storage account"
}

variable "aks_backup_vault_configuration" {
  type = object({
    datastore_type               = string
    redundancy                   = string
    retention_duration_in_days   = number
    cross_region_restore_enabled = bool
    immutability                 = string
    soft_delete                  = string
  })

  default = {
    datastore_type               = "OperationalStore"
    redundancy                   = "ZoneRedundant"
    retention_duration_in_days   = 14
    cross_region_restore_enabled = false
    immutability                 = "Locked"
    soft_delete                  = "On"
  }

  description = "The configuration of the Backup Vault for Azure Kubernetes Services."
}

variable "aks_backup_policy_configuration" {
  type = object({
    backup_start_date         = string
    backup_start_time         = string
    backup_frequency          = string
    backup_weekly_time        = string
    daily_retention_duration  = string
    weekly_retention_duration = string
  })

  default = {
    backup_start_date         = "2025-01-01"
    backup_start_time         = "23:00:00+00:00"
    backup_frequency          = "P1D"
    backup_weekly_time        = "FirstOfWeek"
    daily_retention_duration  = "P7D"
    weekly_retention_duration = "P90D"
  }

  description = "The configuration of the Policy applied to the Backup Vault."
}

variable "aks_namespace_filters" {
  type = object({
    included_namespaces     = optional(list(string), [])
    excluded_namespaces     = optional(list(string), [])
    included_resource_types = optional(list(string), [])
    excluded_resource_types = optional(list(string), [])
    label_selectors         = optional(list(string), [])
  })

  default = {
    included_namespaces     = []
    included_resource_types = []
    excluded_resource_types = []
    label_selectors         = []
  }

  description = "Filters for namespaces to include or exclude in backup."
}
