# Azure Backup for AKS

Azure Backup for AKS is a native, cloud-based backup solution that provides automated, policy-driven protection for Azure Kubernetes Service (AKS) clusters

* **What it does**
Backs up Kubernetes persistent volumes (PVs): Protects data stored in Azure Disks used by AKS workloads.
Backs up metadata: It captures Kubernetes objects like namespaces, deployments, services, etc.
Policy-based automation: You can determine how often a backup will take place. Daily, weekly, etc.
Snapshots: It uses native Azure snapshots, enabling fast, incremental, and point-in-time backups.
Restoring backups: It offers flexible restores, allowing recovery of entire clusters, specific namespaces, or individual persistent volumes.

* It will create a namespace called dataprotection-microsoft with 3 pods.

1. <u>The first pod is for 'Velero' and it orchestrates the actual backup and restore operations.</u>
Velero is an open-source tool used by Azure to snapshot Kubernetes resources and volumes.
It interacts with Azure APIs for snapshot creation, it captures metadata (e.g., deployments, services, PVCs) 
and triggers and manages restore workflows

2. <u>node-agent daemonset (velero-node-agent)</u>
It handles volume snapshots on each AKS node. 
The agent runs on each node in the cluster which coordinates snapshotting of persistent volumes (PVCs)
Ensures data consistency when taking volume-level backups and enables CSI or disk-level backup integration

3. <u>azure-backup-extension</u>
This pod manages communication with Azure Backup service.
It's a control plane extension that integrates Velero with Azure’s Backup Vault and policy engine.
Enforces backup policies
Sends backup status and logs to Azure
Handles scheduling and compliance integration


## Resources that will be created

When using this Azure Backup module, these resources will be created:

* A backup extension for AKS
* Required role assignments
* Two alert rules to notify if a backup or restore failed
* An action group which will trigger if an alert is fired
* The backup container in the storage account
* Trusted access to bypass private endpoint restriction
* A backup policy
* A backup instance

## Prerequisites

* Please check if the region in which the cluster is enabled has support for Azure Backup for AKS.
* A storage account with a private endpoint needs to exist before you can enable the backup module.
* These are the provider registrations which needs to be enabled on the subscription:
  - Microsoft.KubernetesConfiguration
  - Microsoft.DataProtection
  - Microsoft.ContainerService
  - Microsoft.AlertsManagement

<br>
* AKS must also access external endpoints to download container images for running backup pods
and to emit service logs to Microsoft Defender for Endpoint via MDM.
Considering the cluster is deployed in a private virtual network with firewall restrictions,
ensure the following FQDNs or application rules are allowed:<br><br>

<table border="1">
  <tr>
    <td>
    *.microsoft.com, mcr.microsoft.com, data.mcr.microsoft.com, crl.microsoft.com, mscrl.microsoft.com,<br> oneocsp.microsoft.com , *.azure.com, management.azure.com, gcs.prod.monitoring.core.windows.net, *.prod.warm.ingest.monitor.core.windows.net, *.blob.core.windows.net, *.azmk8s.io, ocsp.digicert.com, cacerts.digicert.com, crl3.digicert.com, crl4.digicert.com, ocsp.digicert.cn, cacerts.digicert.cn, cacerts.geotrust.com, cdp.geotrust.com, status.geotrust.com, ocsp.msocsp.com, *.azurecr.io, docker.io, *.dp.kubernetesconfiguration.azure.com.
    </td>
  </tr>
</table>

## Module input variables

| **Variable** | **Notes** |
| ----- | ----- |
| **General** |  |
| enable_backup | The backup module will be enabled by default. Setting this variable to `false` will disable it. |
| aks_backup_storage_account_id | The ID of an existing storage account with Private Endpoint is used by the module to store it's backups |
| aks_rg_id | This will take the current resource group which is created and pass it along to the module |
| enable_weekly_retention | Set this to `true` if you want to enable a second backup which will be done weekly and retained for 90 days |
| backup_alert_group | An azure action group will be created and can be configured to utilize different methods of handling the report if the backup or restore fails |
| aks_rg_id | This need to be set in order for Azure Backup to know where to put the resources, it will default to the resource group where AKS deploys its resources. Or the input variable set with `var.aks_rg_id` when calling the module. |
| **Azure Backup Vault Configuration** |  |
| datastore_type | You can choose between `OperationalStore` or `VaultStore` |
| redundancy | You can choose between `LocallyRedundant`, `ZoneRedundant` or `GeoRedundant`, <br>this cannot be changed once set |
| cross_region_restore_enabled | This will determine if you can restore cross region. <br>Note: This can only be `true` if the redundancy is set to `Georedundant`, <br>and it cannot be disabled once it has been enabled |
| soft_delete | You can choose between `AlwaysOn`, `Off`, and `On` |
| retention_duration_in_days | The soft delete retention duration for this Backup Vault.<br>Possible values are between `14` and `180` |
| immutability | You can choose between `Disabled`, `Locked`, and `Unlocked` |
| **Azure Backup Policy Configuration** |  |
| backup_start_date | Set the daily backup start date in ISO 8601 standard date format |
| backup_start_time | Set the daily backup start time like: 23:00:00+00:00 (+00:00 = time zone offset) |
| backup_frequency | Set the daily backup frequency, example: `PT12H` - Every 12 hours, `P2D` -	Every 2 days, .. |
| backup_weekly_time | Set the weekly backup start time, options: `AllBackup`, `FirstOfDay`, `FirstOfWeek`, `FirstOfMonth` and `FirstOfYear`. <br>Note: It will only apply if `enable weekly retention` is set to true |
| daily_retention_duration | How long the daily backup will be saved, example: `P7D`, ('period','7','Days') |
| weekly_retention_duration | How long the daily backup will be saved, example: `P90D`, ('period','90','Days') |
| **Azure Backup Storage Account Configuration** |  |
| account_replication_type | How the storage account should be replicated, `LRS`, `ZRS`, `GRS` .. |
| min_tls_version | Minimum TLS version |
| access_tier | Whether you want the storage to be in the `Hot` or `Cool` tier. <br>Archive tier is not a valid option |
| **AKS Namespace Filters** |  |
| included_namespaces | Which namespaces you would like to have included in the backup |
| excluded_namespaces | Which namespaces you would like to have excluded in the backup |
| included_resource_types | Which resource types you would like to have included in the backup |
| excluded_resource_types | Which resource types you would like to have excluded in the backup |
| label_selectors | Which labels you would like to have included in the backup |

## Required parameters 

| aks_backup_storage_account_id | The ID of an existing storage account with Private Endpoint is used by the module to store it's backups |

## Usage

### Example: Configure Azure Backup for AKS
Note: Ensure a storage account with Private Endpoint has already been created

```terraform
resource "azurerm_storage_account" "bkp_sa" {
  name                          = "backupprereqstacc099"
  resource_group_name           = azurerm_resource_group.rg_network.name
  location                      = azurerm_resource_group.rg_network.location
  account_tier                  = "Standard"
  account_replication_type      = "ZRS"
  account_kind                  = "StorageV2"
  min_tls_version               = "TLS1_2"
  access_tier                   = "Hot"
  public_network_access_enabled = false
}

# for AKS backup to work you need a pre-exising storage account and PEP
resource "azurerm_private_endpoint" "bkp_private_endpoint" {
  name                = "aks_backup_pep_001"
  resource_group_name = azurerm_resource_group.rg_network.name
  location            = azurerm_resource_group.rg_network.location
  subnet_id           = azurerm_subnet.aks_private_endpoints.id

  lifecycle {
    ignore_changes = [private_dns_zone_group]
  }

  private_service_connection {
    name                           = "aks_backup_psc_001"
    private_connection_resource_id = azurerm_storage_account.bkp_sa.id
    subresource_names              = ["blob"]
    is_manual_connection           = false
  }
}

module "aks" {
  source    = "git::ssh://git@ssh.dev.azure.com/v3/MCP-TenneT/cf-workload-modules/terraform-azurerm-wps-kubernetes?ref=v4.2.0"

  enable_backup                 = true
  fullname                      = "shaks-mgt-prd-euw-${random_string.random.result}"
  shortname                     = "shaksmgtprdeuw${random_string.random.result}"
  location                      = "westeurope"
  enable_weekly_retention       = false
  mandatory_tags                = merge(data.azurerm_subscription.current.tags, { UnitCode = "CPS.MSA.24003.001" })

  aks_backup_storage_account_id  = azurerm_storage_account.bkp_sa.id
  aks_backup_vault_configuration = {
    datastore_type               = "OperationalStore"
    redundancy                   = "ZoneRedundant"
    retention_duration_in_days   = 14
    cross_region_restore_enabled = false
    immutability                 = "Locked" #choose to set to "Unlocked" only for new deployments. Read the notes below.
    soft_delete                  = "On"
  }

  aks_backup_policy_configuration = {
    backup_start_date         = "2025-01-01"
    backup_start_time         = "23:00:00+00:00"
    backup_frequency          = "P1D"
    backup_weekly_time        = "FirstOfWeek"
    datastore_type_daily      = "OperationalStore"
    datastore_type_weekly     = "OperationalStore"
    daily_retention_duration  = "P7D"
    weekly_retention_duration = "P90D"
  }

  aks_backup_sa_configuration = {
    account_replication_type = "ZRS"
    min_tls_version          = "TLS1_2"
    access_tier              = "Hot"
  }

  aks_namespace_filters = {
    included_namespaces     = ["dev-team-store","dev-team-transpedia"]
    excluded_namespaces     = []
    included_resource_types = []
    excluded_resource_types = []
    label_selectors         = []
  }

}
```
## NOTE
<table border="1" style="background-color: yellow;">
  <tr>
    <td><b>!! Important !!</b><br>
<br>If you need to redeploy the cluster you need to manually disable Soft Delete in the portal as the pipeline will fail during destroy.<br>
</td>
    <td><b>!! Important !!</b><br>
<br>By default the immutability of the Backup Vault is set to "Locked". You can choose to set it to "Unlocked" for new deployments. Not possible to unlock existing backup vault as you won't be able to destroy the backup vault.<br>
If you do need to remove it, you will need to stop the backup and wait for the retention period before the removal is not possible or for workaround you can move vault to temporary resource group and recreate vault with Unlocked option. This way, you can easily disable vault immutability from portal and delete the backup if requried in future. Check this User Story - (https://tennet-nl.atlassian.net/browse/HYBCLARC-531) for reference<br>
</td>
  </tr>
</table>

## Optional Parameters

Here's a description of each variable in the provided Terraform code:

* `location`: This is a string variable that specifies the location of the resources. The default value is `westeurope`.
* `aks_namespace_filters`: This is an object, all the options are optional, the default values are `null`<br>
Note: The namespace for the backup extension are automatically excluded per Microsoft guidelines
* `optional_tags`: This can be a string or object if you want to set additional tags on the resources.
* `aks_backup_vault_configuration`: This is an object, all the options are optional
The default values are :
```
default = {
  datastore_type               = "OperationalStore"
  redundancy                   = "ZoneRedundant"
  retention_duration_in_days   = 14
  cross_region_restore_enabled = false
  immutability                 = "Locked"
  soft_delete                  = "On"
}
```

* `aks_backup_policy_configuration`: This is an object, all the options are optional
The default values are :
```
default = {
    backup_start_date         = "2025-01-01"
    backup_start_time         = "23:00:00+00:00"
    backup_frequency          = "P1D"
    backup_weekly_time        = "FirstOfWeek"
    daily_retention_duration  = "P7D"
    weekly_retention_duration = "P90D"
  }
```
* `aks_backup_sa_configuration`: This is an object, all the options are optional
The default values are :
```
default = {
    account_replication_type = "ZRS"
    min_tls_version          = "TLS1_2"
    access_tier              = "Hot"
  }
```
Note: The 'account tier and kind' are automatically set to 'Standard' and 'StorageV2' as Velero does not work otherwise.

* `aks_namespace_filters`: This is an object, all the options are optional
```
default = {
  included_namespaces     = []
  included_resource_types = []
  excluded_resource_types = []
  label_selectors         = []
}
```
Put the namespace in quotes, seperated with a comma like `["dev-team-one","dev-team-two"]`

## Note
If the configuration still fails. You can press the 'Fix configuration error' button which will appear if you select the
backup instance. This will attempt to fix any line-of-sight or role problem.

## Waivers
  checkov:skip=CKV2_AZURE_21: "Ensure Storage logging is enabled for Blob service for read requests"