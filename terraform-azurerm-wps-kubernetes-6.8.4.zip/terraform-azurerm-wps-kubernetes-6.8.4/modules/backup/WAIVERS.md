waiver(s)
  # checkov:skip=CKV2_AZURE_21: "Ensure Storage logging is enabled for Blob service for read requests"