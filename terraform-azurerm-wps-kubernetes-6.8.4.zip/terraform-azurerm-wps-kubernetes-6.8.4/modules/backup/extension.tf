resource "azurerm_kubernetes_cluster_extension" "bkp_extension" {
  name           = "bkp-extension-${var.fullname}"
  cluster_id     = var.aks_id
  extension_type = "microsoft.dataprotection.kubernetes"
  release_train  = "Stable"

  configuration_settings = {
    "credentials.tenantId"       = data.azurerm_client_config.current.tenant_id
    "credentials.subscriptionId" = data.azurerm_client_config.current.subscription_id

    "configuration.backupStorageLocation.config.subscriptionId" = data.azurerm_client_config.current.subscription_id
    "configuration.backupStorageLocation.bucket"                = azurerm_storage_container.bkp_container.name
    "configuration.backupStorageLocation.config.resourceGroup"  = local.resource_group_name
    "configuration.backupStorageLocation.config.storageAccount" = local.aks_backup_storage_account_name
    "configuration.backupStorageLocation.config.useAAD"         = true
  }

  configuration_protected_settings = {
    "credentials.clientId" = var.aks_id
  }
}
