# Change Log

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [v3.0.0] - 8-10-2025

### Removed (Breaking Change)
- Backup - Removed build-in storage account and private endpoint due to ongoing configuration issues with the manual sync
- Sync which was used to force the re-evaluation of the Backup Instance configuration

### Changed
- Wait timer was reduced to 3 minutes and now waits for the Azure Roles to be assigned and propegated, after which the  
backup instance is created.

### Added
- Documentation change to reflect the resource provider Microsoft.AlertsManagement is needed to create metric alerts
- Backup variable `aks_backup_storage_account_id` as there needs to be a pre-existing storage account and PEP

### Migration steps from version 2.x.x of the module
If you want to use the backup module, you first have to set `enable_backup = false` using your previous version of the module, so it removes the current backup resources which includes the storage account.  
Please note that you will also have to disable `soft_delete` via code or manually in the portal, otherwise, the backup instance cannot be removed and the pipeline will fail.  
Next you will need to create your own storage account with PEP and provide the Storage account ID as input variable when calling the AKS module.  
example: `aks_backup_storage_account_id = azurerm_storage_account.bkp_sa.id` 
For a more detailed example please refer to the `/docs/DESIGN.MD`

## [v2.0.0] - 13-08-2025

### Changed (Breaking Change)
- Made the backup module optional, it will be enabled by default and can be disabled by setting the AKS input variable 'enable_backup' to 'false'. This change forces re-creation of backup resources.

### Fixed
- Sync resource block added to force Azure to sync the backup vault to fix configuration error
- Added time resource to delay the sync by 570 seconds to give policy time to set private endpoint storage A Record

### Migration steps from version 1.0.0 of the module

Before using module version 2.x.x, you must ensure Soft Delete is disabled on the Backup Vault. You can do this in one of two ways:
Run module version 4.x.x with aks_backup_vault_configuration.soft_delete = "Off" (See example below)
Or manually disable soft delete in the portal: Kubernetes Cluster's > Backup Vault > Properties blade
Be aware: disabling or re-enabling the module will cause backup resources to be recreated.
If soft delete is still enabled, The Backup Vault cannot be deleted and the pipeline will fail.

Example: ( You need to use the entire object so adjust values accordingly )
```
aks_backup_vault_configuration = {
    datastore_type               = "OperationalStore"
    redundancy                   = "ZoneRedundant"
    retention_duration_in_days   = 14
    cross_region_restore_enabled = false
    immutability                 = "Locked"
    soft_delete                  = "Off"
}
```

## [v1.0.0] - 15-07-2025

Release of the first version of the module

### Added
- Deploying of all resources