resource "azurerm_data_protection_backup_instance_kubernetes_cluster" "bkp_dpbi" {
  name                         = "bkpi-${var.fullname}"
  location                     = var.location
  vault_id                     = azurerm_data_protection_backup_vault.bkp_backup_vault.id
  kubernetes_cluster_id        = var.aks_id
  snapshot_resource_group_name = local.resource_group_name
  backup_policy_id             = azurerm_data_protection_backup_policy_kubernetes_cluster.bkp_policy.id

  backup_datasource_parameters {
    cluster_scoped_resources_enabled = true
    volume_snapshot_enabled          = true

    included_namespaces = var.aks_namespace_filters.included_namespaces
    excluded_namespaces = setunion(
      var.aks_namespace_filters.excluded_namespaces,
      ["dataprotection-microsoft"]
    )
    included_resource_types = var.aks_namespace_filters.included_resource_types
    excluded_resource_types = var.aks_namespace_filters.excluded_resource_types
    label_selectors         = var.aks_namespace_filters.label_selectors
  }
  depends_on = [
    time_sleep.wait_for_rbac_propagation,
    azurerm_kubernetes_cluster_extension.bkp_extension
  ]
}
