locals {
  tags = merge(var.optional_tags, var.mandatory_tags, {
    CreatedBy = "terraform"
    module    = "azure-kubernetes-service"
  })

  backup_repeating_time_interval = format(
    "R/%sT%s/%s",
    var.aks_backup_policy_configuration.backup_start_date,
    var.aks_backup_policy_configuration.backup_start_time,
    var.aks_backup_policy_configuration.backup_frequency
  )

  resource_group_name             = basename(var.aks_rg_id)
  aks_backup_storage_account_name = element(reverse(split("/", var.aks_backup_storage_account_id)), 0)
}
