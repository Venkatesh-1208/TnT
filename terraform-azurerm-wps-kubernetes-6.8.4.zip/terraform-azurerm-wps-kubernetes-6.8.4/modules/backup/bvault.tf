resource "azurerm_data_protection_backup_vault" "bkp_backup_vault" {
  name                         = "bvault-${var.fullname}-001"
  location                     = var.location
  resource_group_name          = local.resource_group_name
  datastore_type               = var.aks_backup_vault_configuration.datastore_type
  redundancy                   = var.aks_backup_vault_configuration.redundancy
  retention_duration_in_days   = var.aks_backup_vault_configuration.retention_duration_in_days
  immutability                 = var.aks_backup_vault_configuration.immutability
  soft_delete                  = var.aks_backup_vault_configuration.soft_delete
  cross_region_restore_enabled = var.aks_backup_vault_configuration.redundancy == "GeoRedundant" ? var.aks_backup_vault_configuration.cross_region_restore_enabled : null

  identity {
    type = "SystemAssigned"
  }

  tags = local.tags
}

resource "azurerm_kubernetes_cluster_trusted_access_role_binding" "bkp_trusted_access" {
  kubernetes_cluster_id = var.aks_id
  name                  = "backup-trusted-access"
  roles                 = ["Microsoft.DataProtection/backupVaults/backup-operator"]
  source_resource_id    = azurerm_data_protection_backup_vault.bkp_backup_vault.id
}
