variable "container_log_v2_enabled" {
  type        = bool
  description = "Flag to enable Azure Monitor ContainerLogV2 schema via Data Collection Rules."
  default     = false
}
