# ==========================================
# 📊 Consolidated AKS Monitoring Rule Blocks
# ==========================================

# Single unified rule that covers Linux, Windows, and Mixed-OS AKS Clusters
resource "azurerm_monitor_data_collection_rule" "aks_container_insights" {
  count               = var.container_log_v2_enabled ? 1 : 0
  name                = "dcr-${var.fullname}-ci-001"
  location            = var.location
  resource_group_name = var.resource_group_name == null ? azurerm_resource_group.aks_resources[0].name : var.resource_group_name

  # NOTE: 'kind' is intentionally omitted here per Azure Monitor standards 
  # to support both Linux and Windows nodes seamlessly within a single rule.

  destinations {
    log_analytics {
      workspace_resource_id = try(azurerm_log_analytics_workspace.law_aks[0].id, var.law_id)
      name                  = "ciworkspace"
    }
  }
 
  data_flow {
    # This group shorthand covers ContainerLogV2, KubeEvents, Perf, and all inventory streams for both OS types.
    streams      = ["Microsoft-ContainerInsights-Group-Default"]
    destinations = ["ciworkspace"]
  }
 
  data_sources {
    extension {
      name           = "ContainerInsightsExtension"
      extension_name = "ContainerInsights"
      streams        = ["Microsoft-ContainerInsights-Group-Default"]
      extension_json = jsonencode({
        dataCollectionSettings = {
          enableContainerLogV2 = true
        }
      })
    }
  }
}

resource "azurerm_monitor_data_collection_rule_association" "aks_container_insights" {
  count                    = var.container_log_v2_enabled ? 1 : 0
  name                     = "dcra-${var.fullname}-ci-001"
  target_resource_id       = azurerm_kubernetes_cluster.aks.id
  data_collection_rule_id  = azurerm_monitor_data_collection_rule.aks_container_insights[0].id
  description              = "Collect AKS logs for mixed/unified Linux and Windows node pool topologies."
}
