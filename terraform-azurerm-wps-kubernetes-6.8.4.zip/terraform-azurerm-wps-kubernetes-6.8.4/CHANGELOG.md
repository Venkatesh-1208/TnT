# Change Log

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [6.8.4] - 10-21-2026

### Added

- Added `pim_exclude_keys` to selectively exclude AKS, Key Vault, and ACR roles from PIM conversion while retaining standing RBAC assignments (#62). Supported keys are `aks_admin`, `aks_cluster_admin`, `kv_admin`, `kv_data_admin`, and `acr_delete`; the default `[]` preserves existing behavior. Excluded roles receive no PIM eligible assignments or role management policies. Excluding already managed PIM resources plans their destruction; review state and ownership before applying.

## [6.8.3]

### Changed

- Added `trusted_root_certificate` to the Application Gateway lifecycle `ignore_changes` list to prevent drift when trusted root certificates are managed externally.

## [6.8.2] - 10-09-2026

### Changed
- Refactored AKS Container Insights monitoring rules to use a single, unified Data Collection Rule (DCR) for both Linux and Windows workloads.
- Replaced individual stream listings with the consolidated shorthand group stream `Microsoft-ContainerInsights-Group-Default`.
- Omitted the `kind` property inside `azurerm_monitor_data_collection_rule` to prevent Azure API payload evaluation schema conflicts in hybrid/Windows clusters.

### Removed
- Removed the standalone `azurerm_monitor_data_collection_rule.aks_container_insights_windows` resource blocks to eliminate resource duplication.

## [6.8.1] - 08-09-2026

### Added
- **Dual-OS ContainerLogV2 Telemetry**: Appended native Windows monitoring components via `azurerm_monitor_data_collection_rule.aks_container_insights_windows` and its accompanying association resource. This brings identical zero-cost compliance telemetry structure for mixed-OS clusters featuring both Windows and Linux node pools.

### Changed
- **Zero-Dependency Core Fallbacks**: Refactored `dcr.tf` to pull `location` data directly from root validation inputs (`var.location`), bypassing redundant downstream resource-to-resource tracking.
- **Dynamic Resource Group Scoping**: Replaced strict collection array indexes (`[0]`) on the internal resource group block with a dynamic ternary validation mechanism (`var.resource_group_name == null ? ...`). This successfully resolves the production-blocking `Invalid index (empty tuple)` crash when module invocations supply a pre-existing infrastructure resource group.


## [6.8.0] - 04-09-2026

### Added
- **Windows Outbound NAT Configuration**: Added optional parameter `outbound_nat_enabled` (type: `bool`, default: `null`) to the object schema of the `aks_nodepools_config` variable map.
- **Conditional Profile Evaluation**: Integrated a schema-safe `dynamic "windows_profile"` block inside the `azurerm_kubernetes_cluster_node_pool.nodepool` resource.

### Changed
- **Node Pool State Alignment**: Refactored Windows node pool profile parsing to report state profiles natively to the Azure Resource Manager API. Passing an implicit `null` constraint stops the Terraform AzureRM provider from flagging false-positive state drift changes (`true -> null`), cleanly resolving the provider-side error that forces node pool replacement (`-/+ destroy and then create replacement`) during AKS version or cluster module upgrades.

## [6.7.0] - 21-08-2026

### Added
- **ContainerLogV2 Support**: Added conditional Azure Monitor Data Collection Rule (DCR) and Data Collection Rule Association (DCRA) to support the high-performance `ContainerLogV2` schema for AKS cluster logging (`dcr.tf`).
- **Feature Toggle Control**: Introduced `container_log_v2_enabled` variable (`variables_dcr.tf`) to safely toggle the DCR and DCRA infrastructure deployment (defaults to `true`).
- **GPU Driver Configuration**: Added `gpu_driver` input attribute inside the `aks_nodepools_config` variable map to configure node pool GPU drivers.

### Changed

- **Log Collection Architecture**: Migrated standard extension-based log forwarding to a structured Azure Monitor DCR-driven flow, updating streams for container logs, Kubernetes events, and node/pod/service inventories.
- **AppGateway Lifecycle Management**: Appended `ssl_certificate` to the `ignore_changes` array inside the `azurerm_application_gateway` lifecycle block to prevent resource management conflicts with Ingress-managed certificates (`kubectl`).

## [6.6.0] - 09-08-2026

### Added

- Added `aks_diagnostic_log_categories` input variable to make AKS diagnostic logging configurable.
- Consumers can configure either diagnostic log category groups or individual log categories.
- The default remains `allLogs` and `audit` to preserve the existing logging configuration and avoid changes to existing deployments.
- `AllMetrics` remains enabled.

## [6.5.0] - 17-06-2026

### Added

- Input variable `enabled` for the Web Application Firewall Policy which defaults to `true`

## [6.4.0] - 11-06-2026

### Added

- Input variable `domain_name_label` for the public IP which defaults to `null` if omitted
- Input variable `web_app_routing` for AKS. This object features attributes `dns_zone_ids` and `default_nginx_controller`.
This entire object defaults to `null` if omitted

## [6.3.0] - 26-05-2026

### Added

- Allow oms_agent option `msi_auth_for_monitoring_enabled` and set the default value to `true`

## [6.2.1] - 18-02-2026

### Changed

- Updated Backup immutability docs check design file
- Updated managed identity to start with mi-<name of aks|appgw resource>
- Updated lifecycle block for application gateway to add url_path_map and to ignore tags for keyvault certificates.
- Updated output name of keyvault to key_vault_id. Make sure to udpate code (to module.aks.key_vault_id) if referring module.aks.key_vault.id

## [6.1.1] - 26-11-2025

### Changed

- Adjusted module output from `key_vault`, `law_id` and `resource_group_id` to prevent error "Invalid index" when own resources are used.
- Renamed `azurerm_monitor_diagnostic_setting` nested block name from `metric` to `enabled_metric` as is required for future update to Azurerm v5.x+
- Renamed `azurerm_key_vault` parameter name from `enable_rbac_authorization` to `rbac_authorization_enabled` as is required for future update to Azurerm v5.x+

### Removed

- Removed parameter `diagnostic_metrics_enabled` from resource `enabled_metric` as it has been depricated in Azurerm v5.x+
- Removed variable `diagnostic_metrics_enabled` as it is no longer used.

## [6.1.0] - 22-10-2025

### Added

- Enable the option to set request_body_enforcement in the WAF policy settings.

## [6.0.0] - 8-10-2025

### Removed (Breaking Change)

- Backup - Removed build-in storage account and private endpoint due to ongoing configuration issues with the manual sync
- Sync which was used to force the re-evaluation of the Backup Instance configuration

### Changed

- Backup - Wait timer was reduced to 3 minutes and now waits for the Azure Roles to be assigned and propegated,  
after which the backup instance is created.

### Added

- Added lifecycle block to ignore changes to the Defender LAW to prevent updating cluster
- Backup module documentation to reflect that the Microsoft.AlertsManager provider is a requirement
- Backup variable `aks_backup_storage_account_id` as there needs to be a pre-existing storage account and PEP

### Migration steps from version 5.x.x of the module

If you want to use the backup module, you first have to set `enable_backup = false` using your previous version of the module, so it removes the current backup resources which includes the storage account.  
Please note that you will also have to disable `soft_delete` via code or manually in the portal, otherwise, the backup instance cannot be removed and the pipeline will fail.  
Next you will need to create your own storage account with PEP and provide the Storage account ID as input variable when calling the AKS module.  
example: `aks_backup_storage_account_id = azurerm_storage_account.bkp_sa.id`
For a more detailed example please refer to the `/docs/DESIGN.MD`

## [5.1.1] - 22-09-2025

### Changed

- Bug Fix for backup role assignment replacement issue (passing aks resource group id instead of aks rg name)
- Remove role assignment for extensionmanager-<aks-name> as this identity is not anymore created from Azure.

## [5.1.0] - 27-08-2025

### Changed

- Added PIM for K8s RBAC cluster admin and admin roles (privildge role)
- Added WAF exclusion ruleset for managed rules.
- update trigger for backup vault.

## [5.0.0] - 13-08-2025

### Changed (Breaking Change)

- Made the backup module optional, it will be enabled by default and can be disabled by setting the AKS input variable 'enable_backup' to 'false'. This change forces re-creation of backup resources.

### Fixed

- PIM Max expiration date variable `expire_after` set for eligible assignments and set default to 365 days
- Sync resource block added to force Azure to sync the backup vault to fix configuration error
- Added time resource to delay the sync by 570 seconds to give policy time to set private endpoint storage A Record
- Added lifecycle block to ignore changes to managed_rules in `azurerm_web_application_firewall_policy`
- Changed AppGW variable `availability_zones` default back to `null` to prevent re-deployment of appgw

### Migration steps from version 4.x.x of the module

Before using module version 5.x.x, you must ensure Soft Delete is disabled on the Backup Vault. You can do this in one of two ways:
Run module version 4.x.x with aks_backup_vault_configuration.soft_delete = "Off" (See example below)
Or manually disable soft delete in the portal: Kubernetes Cluster's > Backup Vault > Properties blade
Be aware: disabling or re-enabling the module will cause backup resources to be recreated.
If soft delete is still enabled, The Backup Vault cannot be deleted and the pipeline will fail.

Second, the Immutability of the backup vault needs to be set to `Unlocked`, `Locked` or `Disabled`.
If you choose `Unlocked` you can manually disable Immutability in the portal. But with `Locked`, its irreversible.
This setting ensures the vault cannot be accidentally deleted so it is recommended to set it to `Locked`.

**For NEW deployments:**

- Set `immutability = "Unlocked"` in your configuration. This allows you to modify or delete the vault if needed during initial setup. Once satisfied with the configuration, you can lock it for additional security.

**For EXISTING deployments:**

- It is currently set to `"Locked"`, it **cannot** be changed back to `"Unlocked"` via Terraform (Azure limitation). You must keep `immutability = "Locked"` in your configuration to match the current state. Read [Design file](modules/backup/docs/DESIGN.md) to know more.

**Recommendation:**

- New deployments should use `immutability = "Unlocked"` initially. After validating the backup configuration, lock it using below example. This provides flexibility during setup while maintaining security in production.

Example: ( You need to use the entire object so adjust values accordingly )

```
aks_backup_vault_configuration = {
    datastore_type               = "OperationalStore"
    redundancy                   = "ZoneRedundant"
    retention_duration_in_days   = 14
    cross_region_restore_enabled = false
    immutability                 = "Locked"
    soft_delete                  = "Off"
}
```

## [4.3.0] - 28-07-2025

### Added

- Option to select OS Type and SKU for node pools
  
## [4.2.0] - 14-07-2025

### Added

- Azure Backup for AKS module
- Variable aks_version added for upgrading cluster node pool

## Changed

- PIM Active rule assignment set to 'false'

## [4.1.2] - 09-07-2025

### Fixed

- Enforced expiration for all PIM assignments by setting expiration_required = true for both eligible and active assignments.
- Ensures all group memberships (including direct ones).

## [4.1.1] - 09-07-2025

### Fixed

- Enforced expiration duration For PIM eligible group assignments to comply with Azure policy "ExpirationRule".
- Now using duration = var.pim_group_assignment_expiration which default set to 'P7D'

## [4.1.0] - 08-07-2025

### Added

- Privileged Access Group Eligibility
- Created locals.tf and moved all local variables into it
- Reduced unnecessary min_count and max_count to adapt to limited CPU availability in West Europe region

## [4.0.0] - 20-06-2025

### Fixed (Breaking Change)

- Create custom rules in WAF policy
- Change default for availability zones from [] to ["1", "2", "3"]

### Added

- Configure exceptions for OWASP rules
- Possibility to disable OWASP rules

### Removed

### Migration steps from version 3.x.x of the module

Before using version 4.x.x of the module, please make sure that the variable `availability_zones` is set when calling the AKS module. Most previous deployments of the application gateway are NOT zone redundant.
When that is the case, the `availability_zones` needs to be set to `[]`.
In caste the `availability_zones` variable is not specified when calling the module, the application gateway will be destroyed and created again.

## [3.2.4] - 18-06-2025

### Added

- Possibility to enable snapshot controller

## [3.2.3] - 18-06-2025

### Fixed

- Due to update to Azurerm 4.0
- Need to change [each.key].id to [each.key].object_id

## [3.2.2] - 04-06-2025

### Added

- Possibility to add support plan for AKS

## [3.2.1] - 21-05-2025

### Fixed

- PIP also having availability zone when necessary
- Data for Resource Group having correct count
  
## [3.2.0] - 21-05-2025

### Added

- Possibility to add custom rules to WAF Policy for App GW
- Availability zone parameter for App GW
- Possibility to use existing resource group

## [3.1.0] - 08-05-2025

### Changed

- added redirect_configuration in ignore_changes for appgw to fix InvalidResourceReference error in pipeline.
- fix key_vault output block to have [count.index], so that we can directly access any property in glue code.

## [3.0.0] - 24-04-2025

### Changed (Breaking Change)

- updated Azure Kubernetes Service RBAC Cluster Admin to principal deploying the cluster (if same permission added in your glue code, you need to remove first, else it will give 409 Conflict error - RoleAssignmentExists)
- updated tf provider version. (Note: upgrade azurerm("~>4.0") and azuread("~>3.0") version in your glue code)
- removed duplicate code for ad group creation for AKS. Added new code to use for_each loop for creating AD groups. (Pls note: since AD groups are re-creating, you need to onboard groups again on Omada).

### Added

- add variable for setting scale_down_mode on nodes pool(s) and default system nodes
- add output block for key vault

## [2.1.0] - 20-02-2025

### Fixed

- provided Azure Kubernetes Service RBAC Writer to principal deploying the cluster

### Added

- add variable for setting taints on nodes pool(s)
- add variable for setting labels on node pool(s)
- add variable for setting labels on system pool
- add variable to change the name of the node pool(s)
- add example to main.tf file in the tests folder on deploying multiple node pools

## [2.0.1] - 09-01-2025

### Fixed

- provided network contributor permissions on the cluster
- Fixed naming of system_nodes

### Added

- Added output blocks in outputs.tf

## [2.0.0] - 04-11-2024

### Fixed

### Added

- Managing trusted root SSL certificates that are stored in a key vault as secret
- Managing SSL certificates that are stored in a key vault as a certificate

### Removed

- ssl_certificate and trusted_root_certificate from lifecycle block of the application gateway

### Migration steps from version 1.x.x of the module

Before using version 2.x.x of the module, please make sure all trusted root and ssl certificates are added to the configuration. When they are not added to the configuration, they may get lost or the module may fail.

## [1.3.2] - 08-10-2024

### Fixed

- Move SSL policy from predefined to CustomV2 to be able to configure the SSL policy with parameters and to support TLS 1.3 only, when required.

### Added

- cipher_suites parameter to specify the used ciphers for the SSL policy
- min_protocol_version to set the minimum SSL version for the SSL policy

### Removed

- policy_name parameter, because it is not used within the SSL policy anymore

## [v1.3.1] - 30-09-2024

### Fixed

- Added extra ignores on application gateway to allow manual uploading of root certificates
- Fixed role assignments on acr when a extern acr is used

## [v1.3.0] - 27-09-2024

### Added

- Add ability to specify the monitor_metrics block to be able to use managed prometheus

## [v1.2.0] - 02-09-2024

Entra ID addition

### Added

- Entra ID groups and PIM assignments for Key Vault and Container Registry

## [v1.1.0] - 22-08-2024

Update module to include findings during deployment of AKS

### Added

- Cost Analysis on Cluster
- Lifecycle on DNS records
- Audit Logging
  
### Fixed

- Permissions on VNET for AKS Managed Identity

## Release [v1.0.0] - 12-08-2024

Release of the first version of the module

### Added

- Deploying of all resources

### Changed

### Fixed
