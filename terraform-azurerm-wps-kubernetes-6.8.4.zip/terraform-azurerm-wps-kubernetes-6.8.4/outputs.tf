output "kubernetes_cluster" {
  description = "The AKS cluster Details"
  value       = azurerm_kubernetes_cluster.aks
  sensitive   = true
}
output "resource_group_id" {
  description = "The resource group ID"
  value = coalesce(
    try(azurerm_resource_group.aks_resources[0].id, null),
    try(data.azurerm_resource_group.aks_resources[0].id, null)
  )
}

output "application-gateway" {
  description = "The AKS module Key vault Details"
  value       = azurerm_application_gateway.appgw
  sensitive   = true
}

output "appgw-public-ip" {
  description = "The AKS module Key vault Details"
  value       = azurerm_public_ip.appgw_pip.ip_address
}

output "appgw-waf-policy" {
  description = "The Application GW WAF Policy Id"
  value       = azurerm_web_application_firewall_policy.wafpolicy-default-aks
}

output "law_id" {
  description = "The Log Analytics workspace Id"
  value = coalesce(
    try(azurerm_log_analytics_workspace.law_aks[0].id, null),
    try(var.law_id, null)
  )
}

output "key_vault_id" {
  description = "The Details of the Key Vault"
  value = coalesce(
    try(azurerm_key_vault.keyvault[0].id, null),
    try(var.key_vault_id, null)
  )
  sensitive = true
}
