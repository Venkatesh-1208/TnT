data "azurerm_subscription" "current" {}

data "azuread_client_config" "current" {}

data "azurerm_resource_group" "aks_resources" {
  count = var.resource_group_name == null ? 0 : 1
  name  = var.resource_group_name
}
