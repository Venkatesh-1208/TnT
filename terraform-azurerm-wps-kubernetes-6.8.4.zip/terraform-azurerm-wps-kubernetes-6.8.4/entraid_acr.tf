

resource "azuread_group" "rbac_acr_group" {
  for_each                = local.group_names_map_acr
  display_name            = each.value
  description             = "${each.key} Role for Azure Container Registry"
  security_enabled        = true
  assignable_to_role      = false
  prevent_duplicate_names = true
}

resource "azurerm_role_assignment" "acr_role_assignments" {
  for_each = {
    for k, v in local.group_names_map_acr : k => v
    if var.pim_enabled
    ? !contains(values(local.pim_group_role_assignments), k)
    : true
  }
  scope                = try(azurerm_container_registry.acr[0].id, var.acr_existing_acr_id)
  role_definition_name = each.key
  principal_id         = azuread_group.rbac_acr_group[each.key].object_id
}
