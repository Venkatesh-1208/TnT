module "backup" {
  count                         = var.enable_backup ? 1 : 0
  source                        = "./modules/backup"
  fullname                      = var.fullname
  aks_rg_id                     = var.resource_group_name == null ? azurerm_resource_group.aks_resources[0].id : data.azurerm_resource_group.aks_resources[0].id
  location                      = var.location
  aks_backup_storage_account_id = var.aks_backup_storage_account_id
  aks_principal_id              = azurerm_user_assigned_identity.aks_user_assigned_identity.principal_id
  aks_id                        = azurerm_kubernetes_cluster.aks.id
  enable_weekly_retention       = var.enable_weekly_retention
  mandatory_tags                = local.tags

  aks_backup_vault_configuration = {
    datastore_type               = var.aks_backup_vault_configuration.datastore_type
    redundancy                   = var.aks_backup_vault_configuration.redundancy
    retention_duration_in_days   = var.aks_backup_vault_configuration.retention_duration_in_days
    cross_region_restore_enabled = var.aks_backup_vault_configuration.cross_region_restore_enabled
    immutability                 = var.aks_backup_vault_configuration.immutability
    soft_delete                  = var.aks_backup_vault_configuration.soft_delete
  }

  aks_backup_policy_configuration = {
    backup_start_date         = var.aks_backup_policy_configuration.backup_start_date
    backup_start_time         = var.aks_backup_policy_configuration.backup_start_time
    backup_frequency          = var.aks_backup_policy_configuration.backup_frequency
    backup_weekly_time        = var.aks_backup_policy_configuration.backup_weekly_time
    daily_retention_duration  = var.aks_backup_policy_configuration.daily_retention_duration
    weekly_retention_duration = var.aks_backup_policy_configuration.weekly_retention_duration
  }

  aks_namespace_filters = {
    included_namespaces     = var.aks_namespace_filters.included_namespaces
    excluded_namespaces     = var.aks_namespace_filters.excluded_namespaces
    included_resource_types = var.aks_namespace_filters.included_resource_types
    excluded_resource_types = var.aks_namespace_filters.excluded_resource_types
    label_selectors         = var.aks_namespace_filters.label_selectors
  }

  depends_on = [
    azurerm_resource_group.aks_resources,
    azurerm_kubernetes_cluster.aks
  ]
}
