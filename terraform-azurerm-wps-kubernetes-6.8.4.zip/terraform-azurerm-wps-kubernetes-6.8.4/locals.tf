locals {
  appgw_name                  = "appgw-${var.fullname}-001"
  appgw_name_fqdn             = "appgw-${var.fullname}-001.${var.appgw_dns_zone_name}"
  appgw_managed_identity_name = "mi-${local.appgw_name}"
  group_names_map_acr = {
    "AcrDelete"           = coalesce(var.group_names_acr.AcrDelete, "RES_${var.shortname}001_${var.rbac_roles_acr[0]}")
    "AcrImageSigner"      = coalesce(var.group_names_acr.AcrImageSigner, "RES_${var.shortname}001_${var.rbac_roles_acr[1]}")
    "AcrPull"             = coalesce(var.group_names_acr.AcrPull, "RES_${var.shortname}001_${var.rbac_roles_acr[2]}")
    "AcrPush"             = coalesce(var.group_names_acr.AcrPush, "RES_${var.shortname}001_${var.rbac_roles_acr[3]}")
    "AcrQuarantineReader" = coalesce(var.group_names_acr.AcrQuarantineReader, "RES_${var.shortname}001_${var.rbac_roles_acr[4]}")
    "AcrQuarantineWriter" = coalesce(var.group_names_acr.AcrQuarantineWriter, "RES_${var.shortname}001_${var.rbac_roles_acr[5]}")
  }
  group_names_map_kv = {
    "Administrator"                  = coalesce(var.group_names_kv.Administrator, "RES_${var.shortname}001_${var.rbac_roles_kv[0]}")
    "Certificate User"               = coalesce(var.group_names_kv.Certificates_User, "RES_${var.shortname}001_${var.rbac_roles_kv[1]}")
    "Certificates Officer"           = coalesce(var.group_names_kv.Certificates_Officer, "RES_${var.shortname}001_${var.rbac_roles_kv[2]}")
    "Contributor"                    = coalesce(var.group_names_kv.Contributor, "RES_${var.shortname}001_${var.rbac_roles_kv[3]}")
    "Crypto Officer"                 = coalesce(var.group_names_kv.Crypto_Officer, "RES_${var.shortname}001_${var.rbac_roles_kv[4]}")
    "Crypto Service Encryption User" = coalesce(var.group_names_kv.Crypto_Service_Encryption_User, "RES_${var.shortname}001_${var.rbac_roles_kv[5]}")
    "Crypto Service Release User"    = coalesce(var.group_names_kv.Crypto_Service_Release_User, "RES_${var.shortname}001_${var.rbac_roles_kv[6]}")
    "Crypto User"                    = coalesce(var.group_names_kv.Crypto_User, "RES_${var.shortname}001_${var.rbac_roles_kv[7]}")
    "Data Access Administrator"      = coalesce(var.group_names_kv.Data_Access_Administrator, "RES_${var.shortname}001_${var.rbac_roles_kv[8]}")
    "Reader"                         = coalesce(var.group_names_kv.Reader, "RES_${var.shortname}001_${var.rbac_roles_kv[9]}")
    "Secrets Officer"                = coalesce(var.group_names_kv.Secrets_Officer, "RES_${var.shortname}001_${var.rbac_roles_kv[10]}")
    "Secrets User"                   = coalesce(var.group_names_kv.Secrets_User, "RES_${var.shortname}001_${var.rbac_roles_kv[11]}")
  }
  group_names_map_aks = {
    "RBAC Admin"         = coalesce(var.group_names.AzureKubernetesServiceRBACAdmin, "RES_${azurerm_kubernetes_cluster.aks.name}_Azure Kubernetes Service RBAC Admin")
    "RBAC Cluster Admin" = coalesce(var.group_names.AzureKubernetesServiceRBACClusterAdmin, "RES_${azurerm_kubernetes_cluster.aks.name}_Azure Kubernetes Service RBAC Cluster Admin")
    "RBAC Reader"        = coalesce(var.group_names.AzureKubernetesServiceRBACReader, "RES_${azurerm_kubernetes_cluster.aks.name}_Azure Kubernetes Service RBAC Reader")
    "RBAC Writer"        = coalesce(var.group_names.AzureKubernetesServiceRBACWriter, "RES_${azurerm_kubernetes_cluster.aks.name}_Azure Kubernetes Service RBAC Writer")
  }
  group_role_assignments = {
    "aks_admin"         = "Azure Kubernetes Service RBAC Admin"
    "aks_cluster_admin" = "Azure Kubernetes Service RBAC Cluster Admin"
    "kv_admin"          = "Key Vault Administrator"
    "kv_data_admin"     = "Key Vault Data Access Administrator"
    "acr_delete"        = "AcrDelete"
  }

  scope_mappings = {
    "aks_admin"         = azurerm_kubernetes_cluster.aks.id
    "aks_cluster_admin" = azurerm_kubernetes_cluster.aks.id
    "kv_admin"          = try(azurerm_key_vault.keyvault[0].id, var.key_vault_id)
    "kv_data_admin"     = try(azurerm_key_vault.keyvault[0].id, var.key_vault_id)
    "acr_delete"        = try(azurerm_container_registry.acr[0].id, var.acr_existing_acr_id)
  }

  # Keep this filter independent of resource IDs so standing assignment keys
  # remain known during planning, including when resources are newly created.
  pim_group_role_assignments = {
    for k, v in local.group_role_assignments : k => v
    if !contains(var.pim_exclude_keys, k)
  }

  valid_group_assignments = {
    for k, v in local.pim_group_role_assignments : k => v
    if can(local.scope_mappings[k]) && local.scope_mappings[k] != null
  }

  scope_subscription_mappings = {
    for k, v in local.valid_group_assignments : k => "/subscriptions/${split("/", local.scope_mappings[k])[2]}"
  }

  group_mappings = {
    "aks_admin"         = azuread_group.azurekubernetes_rbac_groups["RBAC Admin"].object_id
    "aks_cluster_admin" = azuread_group.azurekubernetes_rbac_groups["RBAC Cluster Admin"].object_id
    "kv_admin"          = azuread_group.rbac_keyvault_group["Administrator"].object_id
    "kv_data_admin"     = azuread_group.rbac_keyvault_group["Data Access Administrator"].object_id
    "acr_delete"        = azuread_group.rbac_acr_group["AcrDelete"].object_id
  }
}
