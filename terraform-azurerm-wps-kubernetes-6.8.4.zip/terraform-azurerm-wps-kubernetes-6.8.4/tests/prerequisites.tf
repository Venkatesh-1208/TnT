resource "random_string" "random" {
  count   = 2
  length  = 5
  special = false
  lower   = true
  upper   = false
}

resource "azurerm_resource_group" "rg_network" {
  name     = "aks-prerequisites-${random_string.random[0].result}"
  location = "west Europe"
}

resource "azurerm_virtual_network" "vnet" {
  name                = "vnet-aks-${random_string.random[0].result}-001"
  location            = azurerm_resource_group.rg_network.location
  resource_group_name = azurerm_resource_group.rg_network.name
  address_space       = ["172.20.0.0/16"]
}

resource "azurerm_subnet" "aks_system_nodes" {
  name                 = lower("aks_system_nodes_001")
  virtual_network_name = azurerm_virtual_network.vnet.name
  resource_group_name  = azurerm_virtual_network.vnet.resource_group_name
  address_prefixes     = ["172.20.1.0/24"]
}

resource "azurerm_subnet" "aks_system_pods" {
  name                 = lower("aks_system_pods_001")
  virtual_network_name = azurerm_virtual_network.vnet.name
  resource_group_name  = azurerm_virtual_network.vnet.resource_group_name
  address_prefixes     = ["172.20.2.0/24"]

  delegation {
    name = "aks-delegation"

    service_delegation {
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
      ]
      name = "Microsoft.ContainerService/managedClusters"
    }
  }
}

resource "azurerm_subnet" "aks_workload_nodes" {
  name                 = lower("aks_workload_nodes_001")
  virtual_network_name = azurerm_virtual_network.vnet.name
  resource_group_name  = azurerm_virtual_network.vnet.resource_group_name
  address_prefixes     = ["172.20.3.0/24"]
}

resource "azurerm_subnet" "aks_workload_pods" {
  name                 = lower("aks_workload_pods_001")
  virtual_network_name = azurerm_virtual_network.vnet.name
  resource_group_name  = azurerm_virtual_network.vnet.resource_group_name
  address_prefixes     = ["172.20.4.0/24"]

  delegation {
    name = "aks-delegation"

    service_delegation {
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
      ]
      name = "Microsoft.ContainerService/managedClusters"
    }
  }
}

resource "azurerm_subnet" "aks_private_endpoints" {
  name                 = lower("aks_private_endpoints_001")
  virtual_network_name = azurerm_virtual_network.vnet.name
  resource_group_name  = azurerm_virtual_network.vnet.resource_group_name
  address_prefixes     = ["172.20.201.0/24"]
}

resource "azurerm_subnet" "aks_appgw_range" {
  name                 = lower("aks_appgw_001")
  virtual_network_name = azurerm_virtual_network.vnet.name
  resource_group_name  = azurerm_virtual_network.vnet.resource_group_name
  address_prefixes     = ["172.20.30.0/24"]
}

resource "azurerm_route_table" "rt001" {
  depends_on          = [azurerm_virtual_network.vnet]
  name                = "rt-aks-001"
  location            = azurerm_resource_group.rg_network.location
  resource_group_name = azurerm_resource_group.rg_network.name
}

resource "azurerm_route" "rt001_routes" {
  name                   = "rt-default-001"
  resource_group_name    = azurerm_route_table.rt001.resource_group_name
  route_table_name       = azurerm_route_table.rt001.name
  address_prefix         = "0.0.0.0/0"
  next_hop_type          = "VirtualAppliance"
  next_hop_in_ip_address = azurerm_firewall.fw_aks.ip_configuration[0].private_ip_address
}

resource "azurerm_subnet_route_table_association" "rta_system_nodes" {
  subnet_id      = azurerm_subnet.aks_system_nodes.id
  route_table_id = azurerm_route_table.rt001.id
}

resource "azurerm_subnet_route_table_association" "rta_system_pods" {
  subnet_id      = azurerm_subnet.aks_system_pods.id
  route_table_id = azurerm_route_table.rt001.id
}

resource "azurerm_subnet_route_table_association" "rta_pool1_nodes" {
  subnet_id      = azurerm_subnet.aks_workload_nodes.id
  route_table_id = azurerm_route_table.rt001.id
}

resource "azurerm_subnet_route_table_association" "rta_pool1_pods" {
  subnet_id      = azurerm_subnet.aks_workload_pods.id
  route_table_id = azurerm_route_table.rt001.id
}

resource "azurerm_private_dns_zone" "dns_acr" {
  name                = "privatelink.azurecr.io"
  resource_group_name = azurerm_resource_group.rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "vnet_acr_dns" {
  name                  = "aks_${random_string.random[0].result}_acr"
  resource_group_name   = azurerm_resource_group.rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.dns_acr.name
  virtual_network_id    = azurerm_virtual_network.vnet.id
}

resource "azurerm_private_dns_zone" "dns_aks" {
  name                = "privatelink.westeurope.azmk8s.io"
  resource_group_name = azurerm_resource_group.rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "vnet_aks_dns" {
  name                  = "aks_${random_string.random[0].result}_dns"
  resource_group_name   = azurerm_resource_group.rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.dns_aks.name
  virtual_network_id    = azurerm_virtual_network.vnet.id
}

resource "azurerm_private_dns_zone" "dns_keyvault" {
  name                = "privatelink.vault.azure.net"
  resource_group_name = azurerm_resource_group.rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "vnet_keyvault_dns" {
  name                  = "keyvault_${random_string.random[0].result}_dns"
  resource_group_name   = azurerm_resource_group.rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.dns_keyvault.name
  virtual_network_id    = azurerm_virtual_network.vnet.id
}

resource "azurerm_subnet" "fw_subnet" {
  name                 = "AzureFirewallSubnet"
  resource_group_name  = azurerm_resource_group.rg_network.name
  virtual_network_name = azurerm_virtual_network.vnet.name
  address_prefixes     = ["172.20.10.0/24"]
}

resource "azurerm_public_ip" "fw_pip" {
  name                = "fw_${random_string.random[0].result}_pip"
  location            = azurerm_resource_group.rg_network.location
  resource_group_name = azurerm_resource_group.rg_network.name
  allocation_method   = "Static"
  sku                 = "Standard"
}

resource "azurerm_firewall" "fw_aks" {
  name                = "fw${random_string.random[0].result}001"
  location            = azurerm_resource_group.rg_network.location
  resource_group_name = azurerm_resource_group.rg_network.name
  sku_name            = "AZFW_VNet"
  sku_tier            = "Standard"

  ip_configuration {
    name                 = "configuration"
    subnet_id            = azurerm_subnet.fw_subnet.id
    public_ip_address_id = azurerm_public_ip.fw_pip.id
  }
}

resource "azurerm_firewall_network_rule_collection" "example" {
  name                = "${random_string.random[0].result}collection"
  azure_firewall_name = azurerm_firewall.fw_aks.name
  resource_group_name = azurerm_resource_group.rg_network.name
  priority            = 100
  action              = "Allow"

  rule {
    name = "allowall"

    source_addresses = [
      "172.20.0.0/16",
    ]

    destination_ports = [
      "*",
    ]

    destination_addresses = [
      "0.0.0.0/0"
    ]

    protocols = [
      "TCP",
      "UDP",
    ]
  }
}

resource "azurerm_storage_account" "bkp_sa" {
  name                          = "bkpsaprereq${random_string.random[0].result}765"
  resource_group_name           = azurerm_resource_group.rg_network.name
  location                      = azurerm_resource_group.rg_network.location
  account_tier                  = "Standard"
  account_replication_type      = "ZRS"
  account_kind                  = "StorageV2"
  min_tls_version               = "TLS1_2"
  access_tier                   = "Hot"
  public_network_access_enabled = false
}

# for AKS backup to work you need a pre-exising storage account and PEP
resource "azurerm_private_endpoint" "bkp_private_endpoint" {
  name                = "aks_backup_pep_001"
  resource_group_name = azurerm_resource_group.rg_network.name
  location            = azurerm_resource_group.rg_network.location
  subnet_id           = azurerm_subnet.aks_private_endpoints.id

  lifecycle {
    ignore_changes = [private_dns_zone_group]
  }

  private_service_connection {
    name                           = "aks_backup_psc_001"
    private_connection_resource_id = azurerm_storage_account.bkp_sa.id
    subresource_names              = ["blob"]
    is_manual_connection           = false
  }
}
