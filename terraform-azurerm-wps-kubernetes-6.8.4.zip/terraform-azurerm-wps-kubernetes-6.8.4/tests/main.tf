module "aks" {

  depends_on = [
    azurerm_firewall.fw_aks,
    azurerm_private_dns_zone.dns_acr,
    azurerm_private_dns_zone.dns_aks,
    azurerm_storage_account.bkp_sa
  ]
  source = "../"

  fullname  = "cf-app-prd-euw-${random_string.random[0].result}"
  shortname = "cfappprdeuw${random_string.random[0].result}"

  location                    = "westeurope"
  acr_georeplication_location = "northeurope"
  aks_vnet_id                 = azurerm_virtual_network.vnet.id

  aks_system_nodes_subnet_ids  = [azurerm_subnet.aks_system_nodes.id]
  aks_system_pods_subnet_ids   = [azurerm_subnet.aks_system_pods.id]
  aks_workload_subnet_ids      = [azurerm_subnet.aks_workload_nodes.id]
  aks_workload_pods_subnet_ids = [azurerm_subnet.aks_workload_pods.id]
  private_endpoint_subnet_id   = azurerm_subnet.aks_private_endpoints.id
  appgw_subnet_id              = azurerm_subnet.aks_appgw_range.id
  appgw_private_ip_address     = "172.20.30.10"

  aks_dns_id = azurerm_private_dns_zone.dns_aks.id

  aks_version              = "1.36.2"
  aks_number_of_node_pools = 1

  aks_diagnostic_log_categories = {
    categories = [
      "kube-apiserver",
      "kube-audit-admin",
      "guard"
    ]
  }

  appgw_waf_policy_settings = {
    request_body_enforcement = false
  }
  # aks_number_of_node_pools = 2

  # aks_nodepools_config = {
  #   pool001 = {
  #     name                   = "aca"
  #     vm_size                = "Standard_d4ds_v5"
  #     min_count              = 1
  #     max_count              = 1
  #     enable_auto_scaling    = true
  #     enable_host_encryption = true
  #     max_pods               = 50
  #     os_disk_type           = "Managed"
  #     node_labels            = {
  #       "nodepool" = "aca",
  #       "env"      = "dev"
  #     }
  #     node_taints = [
  #       "key=value:NoSchedule"
  #     ]
  #   },
  #   pool002 = {
  #     name                   = "gam"
  #     vm_size                = "Standard_d4ds_v5"
  #     min_count              = 1
  #     max_count              = 1
  #     enable_auto_scaling    = true
  #     enable_host_encryption = true
  #     max_pods               = 50
  #     os_disk_type           = "Managed"
  #     node_labels            = {
  #       "nodepool" = "gam",
  #       "env"      = "dev"
  #     }
  #   }
  # }

  # acr_existing_acr_id = "/subscriptions/1db02c81-075d-4d9c-804d-c3eac16fb1c0/resourceGroups/rg-portal-platform/providers/Microsoft.ContainerRegistry/registries/crcfportalprdeuw001"

  appgw_waf_managed_rules = {
    managed_rule_set = {
      type    = "OWASP"
      version = "3.2"
      rule_group_overrides = [
        {
          rule_group_name = "REQUEST-920-PROTOCOL-ENFORCEMENT"
          rules = [
            {
              rule_id = "920320"
              enabled = false
            },
            {
              rule_id = "920330"
              enabled = false
            },
            {
              rule_id = "920300"
              enabled = false
            }
          ]
        },
        {
          rule_group_name = "REQUEST-913-SCANNER-DETECTION"
          rules = [
            {
              rule_id = "913101"
              enabled = false
            }
          ]
        },
        {
          rule_group_name = "REQUEST-931-APPLICATION-ATTACK-RFI"
          rules = [
            {
              rule_id = "931130"
              enabled = false
            }
          ]
        },
        {
          rule_group_name = "REQUEST-942-APPLICATION-ATTACK-SQLI"
          rules = [
            {
              rule_id = "942430"
              enabled = false
            },
            {
              rule_id = "942440"
              enabled = false
            },
            {
              rule_id = "942450"
              enabled = false
            }
          ]
        }
      ]
      # exclusions = [
      #   {
      #     match_variable          = "RequestHeaderNames"
      #     selector                = "x-company-secret-header"
      #     selector_match_operator = "Equals"
      #   }
      # ]
    }
  }

  appgw_waf_custom_rules = {
    custom_rules = [
      {
        name      = "BlockEmptyAPIKey"
        priority  = 1
        rule_type = "MatchRule"
        action    = "Block"

        match_conditions = [{
          match_variables = [{
            variable_name = "RequestHeaders"
            selector      = "apikey"
          }]

          operator           = "Regex"
          match_values       = [".+"]
          negation_condition = true
        }]
      }
    ]
  }

  pim_enabled = false

  key_vault_configuration = {
    public_network_access_enabled = true

    network_acls = {
      bypass                     = "AzureServices"
      default_action             = "Allow"
      ip_rules                   = []
      virtual_network_subnet_ids = []
    }
  }

  acr_quarantine_policy_enabled = false

  mandatory_tags = {
    ApplicationName      = "YourAppName"
    ApproverContact      = "ApproverContactValue"
    BusinessContact      = "BusinessContactValue"
    BusinessLevel        = "BusinessLevelValue"
    BusinessUnit         = "BusinessUnitValue"
    CostCentre           = "CostCentreValue"
    DataClassification   = "DataClassificationValue"
    DisasterRecovery     = "DisasterRecoveryValue"
    Environment          = "EnvironmentValue"
    OperationsCommitment = "OperationsCommitmentValue"
    OperationsContact    = "OperationsContactValue"
    OrgCode              = "OrgCodeValue"
    ServiceClass         = "ServiceClassValue"
    SolutionGroup        = "SolutionGroupValue"
    WorkloadName         = "WorkloadNameValue"
  }

  # monitor_metrics = {
  #   annotations_allowed = null
  #   labels_allowed = null
  # }

  aks_backup_vault_configuration = {
    datastore_type               = "OperationalStore"
    redundancy                   = "ZoneRedundant"
    retention_duration_in_days   = 14
    cross_region_restore_enabled = false
    immutability                 = "Disabled"
    soft_delete                  = "Off"
  }

  enable_backup = true

  aks_backup_storage_account_id = azurerm_storage_account.bkp_sa.id
}
