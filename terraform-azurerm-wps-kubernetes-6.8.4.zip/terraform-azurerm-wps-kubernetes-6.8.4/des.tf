resource "azurerm_disk_encryption_set" "des_aks" {
  count               = var.aks_enable_disk_encryption ? 1 : 0
  name                = "des-aks"
  resource_group_name = var.resource_group_name == null ? azurerm_resource_group.aks_resources[0].name : var.resource_group_name
  location            = var.location
  key_vault_key_id    = azurerm_key_vault_key.des_key_aks[0].id

  auto_key_rotation_enabled = false

  identity {
    type = "SystemAssigned"
  }

  tags = local.tags
}

resource "azurerm_role_assignment" "rols_des_aks" {
  count                = var.aks_enable_disk_encryption ? 1 : 0
  scope                = try(azurerm_key_vault.keyvault[0].id, var.key_vault_id)
  role_definition_name = "Key Vault Crypto Service Encryption User"
  principal_id         = azurerm_disk_encryption_set.des_aks[0].identity[0].principal_id
}

resource "azurerm_key_vault_key" "des_key_aks" {
  count = var.aks_enable_disk_encryption ? 1 : 0
  #checkov:skip=CKV_AZURE_40: "Ensure that the expiration date is set on all keys"
  # An expired key for a disk encryption set could cause several issues, so no expiration date has been, making cycling the key a manual action
  #checkov:skip= CKV_AZURE_112: "Ensure that key vault key is backed by HSM"
  # It is not required for the key vault key to be backed by HSM. This is also not determined by the key vault key resource
  name         = "des-aks"
  key_vault_id = try(azurerm_key_vault.keyvault[0].id, var.key_vault_id)
  key_type     = "RSA"
  key_size     = 2048

  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey",
  ]
}
