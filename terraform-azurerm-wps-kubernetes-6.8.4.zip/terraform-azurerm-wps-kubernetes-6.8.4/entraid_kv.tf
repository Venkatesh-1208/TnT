

resource "azuread_group" "rbac_keyvault_group" {
  for_each                = local.group_names_map_kv
  display_name            = each.value
  description             = "${each.key} Role for Key Vault"
  security_enabled        = true
  assignable_to_role      = false
  prevent_duplicate_names = true
}

resource "azurerm_role_assignment" "keyvault_role_assignments" {
  for_each = {
    for k, v in local.group_names_map_kv : k => v
    if var.pim_enabled
    ? !contains(values(local.pim_group_role_assignments), "Key Vault ${k}")
    : true
  }
  scope                = try(azurerm_key_vault.keyvault[0].id, var.key_vault_id)
  role_definition_name = "Key Vault ${each.key}"
  principal_id         = azuread_group.rbac_keyvault_group[each.key].object_id
}
