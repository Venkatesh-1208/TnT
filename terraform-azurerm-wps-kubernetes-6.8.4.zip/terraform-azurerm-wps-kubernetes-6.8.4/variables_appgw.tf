variable "appgw_private_ip_address" {
  type        = string
  description = "The private IP address of the application gateway."
}

variable "appgw_subnet_id" {
  type        = string
  description = "The id of the subnet for the application gateway."
}

variable "appgw_waf_policy_settings" {
  type = object({
    enabled                          = optional(bool)
    mode                             = optional(string)
    request_body_check               = optional(bool)
    request_body_enforcement         = optional(bool)
    file_upload_limit_in_mb          = optional(number)
    max_request_body_size_in_kb      = optional(number)
    request_body_inspect_limit_in_kb = optional(number)
  })
  description = "The WAF policy settings."
  default = {
    enabled                          = true
    mode                             = "Prevention"
    request_body_check               = true
    request_body_enforcement         = true
    file_upload_limit_in_mb          = 100
    max_request_body_size_in_kb      = 128
    request_body_inspect_limit_in_kb = 128
  }
}

variable "availability_zones" {
  type        = list(string)
  description = "The availability zones for the application gateway."
  default     = null
}

variable "appgw_waf_custom_rules" {
  description = "waf_policy"
  type = object({
    custom_rules = optional(list(object({
      enabled   = optional(bool, true)
      name      = optional(string)
      priority  = number
      rule_type = string
      match_conditions = list(object({
        match_values       = optional(list(string))
        operator           = string
        negation_condition = optional(bool, false)
        transforms         = optional(list(string), [])
        match_variables = list(object({
          variable_name = string
          selector      = optional(string)
        }))
      }))
      action = string
    })))
  })
  default = {
    custom_rules = []
  }
}

variable "appgw_waf_managed_rules" {
  type = object({
    managed_rule_set = object({
      type    = optional(string)
      version = optional(string)
      rule_group_overrides = optional(list(object({
        rule_group_name = string
        rules = optional(list(object({
          rule_id = string
          enabled = bool
        })))
      })), [])
      exclusions = optional(list(object({
        match_variable          = string
        selector                = optional(string)
        selector_match_operator = optional(string)
        excluded_rule_set = optional(object({
          type    = string
          version = string
          rule_group = object({
            rule_group_name = string
            excluded_rules  = list(string)
          })
        }))
      })), [])
    })
  })
  description = "The WAF managed rules."
  default = {
    managed_rule_set = {
      type                 = "OWASP"
      version              = "3.2"
      rule_group_overrides = []
      exclusions           = []
    }
  }
}

variable "appgw_sku" {
  type = object({
    name = string
    tier = string
  })
  description = "The SKU of the application gateway."
  default = {
    name = "WAF_v2"
    tier = "WAF_v2"
  }
}

variable "appgw_backend_http_settings" {
  type = object({
    cookie_based_affinity = string
    port                  = number
    protocol              = string
    request_timeout       = number
  })
  description = "The backend HTTP settings."
  default = {
    cookie_based_affinity = "Disabled"
    port                  = 80
    protocol              = "Http"
    request_timeout       = 60
  }
}

variable "appgw_ssl_policy" {
  type = object({
    policy_type          = string
    cipher_suites        = list(string)
    min_protocol_version = string
  })
  description = "The SSL policy."
  default = {
    policy_type = "CustomV2"
    cipher_suites = [
      "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
      "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
      "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256",
      "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384"
      # "TLS_AES_128_GCM_SHA256" !! Added by default and not allowed to be specified here !!
      # "TLS_AES_256_GCM_SHA384" !! Added by default and not allowed to be specified here !!
    ]
    min_protocol_version = "TLSv1_2"
  }
}

variable "appgw_request_routing_rule" {
  type = object({
    rule_type = string
    priority  = number
  })
  description = "The request routing rule."
  default = {
    rule_type = "Basic"
    priority  = 1000
  }
}

variable "appgw_auto_scaling" {
  type = object({
    min_capacity = number
    max_capacity = number
  })
  description = "The auto scaling configuration."
  default = {
    min_capacity = 1
    max_capacity = 2
  }
}

variable "appgw_enable_http2" {
  type        = bool
  description = "Enable HTTP2."
  default     = true
}

variable "appgw_dns_zone_name" {
  type        = string
  description = "The name of the DNS zone used for the SAN name of the certificate for the application gateway."
  default     = "nodomain.local"
}

variable "appgw_ssl_certificates" {
  type = list(object({
    name                = string
    key_vault_secret_id = string
  }))
  description = "The SSL certificates."
  default     = []
}

variable "appgw_trusted_root_certificates" {
  type = list(object({
    name                = string
    key_vault_secret_id = string
  }))
  description = "The SSL certificates."
  default     = []
}
