locals {
  tags = merge(var.optional_tags, var.mandatory_tags, {
    CreatedBy = "terraform"
    module    = "azure-kubernetes-service"
  })
}