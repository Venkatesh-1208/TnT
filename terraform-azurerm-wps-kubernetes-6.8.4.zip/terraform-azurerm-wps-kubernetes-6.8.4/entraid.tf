resource "azuread_group" "azurekubernetes_rbac_groups" {
  for_each                = local.group_names_map_aks
  display_name            = each.value
  description             = "AKS ${each.key} role for the ${azurerm_kubernetes_cluster.aks.name} resource"
  security_enabled        = true
  assignable_to_role      = false
  prevent_duplicate_names = true
}

resource "azurerm_role_assignment" "azurekubernetes_rbac_role_assignments" {
  for_each = {
    for k, v in local.group_names_map_aks : k => v
    if var.pim_enabled
    ? !contains(values(local.pim_group_role_assignments), "Azure Kubernetes Service ${k}")
    : true
  }
  scope                = azurerm_kubernetes_cluster.aks.id
  role_definition_name = "Azure Kubernetes Service ${each.key}"
  principal_id         = azuread_group.azurekubernetes_rbac_groups[each.key].object_id
}
