variable "aks_automatic_upgrade_channel" {
  description = "The automatic channel upgrade setting for the AKS cluster"
  type        = string
  default     = "patch"
}

variable "aks_azure_policy_enabled" {
  description = "Enable Azure Policy for the AKS cluster"
  type        = bool
  default     = true
}

variable "aks_sku_tier" {
  description = "The SKU tier for the AKS cluster"
  type        = string
  default     = "Standard"
}

variable "aks_availability_zones" {
  description = "The availability zones for the AKS cluster"
  type        = list(string)
  default     = [1, 2, 3]
}

variable "aks_oidc_issuer_enabled" {
  description = "Enable OIDC issuer for the AKS cluster"
  type        = bool
  default     = true
}

variable "aks_workload_identity_enabled" {
  description = "Enable workload identity for the AKS cluster"
  type        = bool
  default     = true
}

variable "aks_system_nodes_config" {
  description = "The system node pool configuration"
  type = object({
    vm_size                      = optional(string)
    min_count                    = optional(number)
    max_count                    = optional(number)
    enable_auto_scaling          = optional(bool)
    enable_host_encryption       = optional(bool)
    max_pods                     = optional(number)
    only_critical_addons_enabled = optional(bool)
    os_disk_type                 = optional(string)
    node_labels                  = optional(map(string))
    scale_down_mode              = optional(string)
  })
  default = {
    vm_size                      = "Standard_d4ds_v5"
    min_count                    = 2
    max_count                    = 4
    enable_auto_scaling          = true
    enable_host_encryption       = true
    max_pods                     = 50
    only_critical_addons_enabled = true
    os_disk_type                 = "Managed"
    node_labels                  = {}
    scale_down_mode              = "Delete"
  }
}

variable "aks_system_nodes_upgrade_settings" {
  description = "The system node pool upgrade settings"
  type = object({
    drain_timeout_in_minutes      = optional(number)
    max_surge                     = optional(string)
    node_soak_duration_in_minutes = optional(number)
  })
  default = {
    drain_timeout_in_minutes      = 30
    max_surge                     = 1
    node_soak_duration_in_minutes = 0
  }
}

variable "aks_version" {
  type        = string
  description = "The version of Kubernetes to use for the AKS cluster."
}

variable "aks_local_account_disabled" {
  description = "Disable the local account for the AKS cluster"
  type        = bool
  default     = true
}

variable "aks_network_profile" {
  description = "The network profile for the AKS cluster"
  type = object({
    network_plugin = string
    network_mode   = string
    network_policy = string
    outbound_type  = string
    service_cidr   = string
    dns_service_ip = string
  })
  default = {
    network_plugin = "azure"
    network_mode   = "transparent"
    network_policy = "azure"
    outbound_type  = "userDefinedRouting"
    service_cidr   = "10.0.0.0/16" # This is the default value
    dns_service_ip = "10.0.0.10"   # This is the default value
  }
}

variable "aks_storage_profile" {
  description = "The storage profile for the AKS cluster"
  type = object({
    blob_driver_enabled         = bool
    disk_driver_enabled         = bool
    snapshot_controller_enabled = bool
  })
  default = {
    blob_driver_enabled         = true
    disk_driver_enabled         = true
    snapshot_controller_enabled = true
  }
}

variable "aks_secret_rotation_enabled" {
  description = "Enable secret rotation for the AKS cluster"
  type        = bool
  default     = true
}

variable "aks_active_directory_role_based_access_control" {
  description = "The Azure Active Directory role based access control for the AKS cluster"
  type = object({
    azure_rbac_enabled     = bool
    admin_group_object_ids = list(string)
    tenant_id              = string
  })
  default = {
    azure_rbac_enabled     = true
    admin_group_object_ids = []
    tenant_id              = null
  }
}

variable "aks_private_cluster_enabled" {
  description = "Enable private cluster for the AKS cluster"
  type        = bool
  default     = true
}

variable "aks_dns_id" {
  type        = string
  description = "The id of the private DNS zone."
}

variable "aks_number_of_node_pools" {
  type        = number
  description = "The number of node pools to create."
  default     = 1
}

variable "aks_system_nodes_subnet_ids" {
  type        = list(string)
  description = "The id of the subnet for the system nodes."
}

variable "aks_system_pods_subnet_ids" {
  type        = list(string)
  description = "The id of the subnet for the system pods."
}

variable "aks_workload_subnet_ids" {
  type        = list(string)
  description = "The ids of the subnets for the workload nodes."
}

variable "aks_workload_pods_subnet_ids" {
  type        = list(string)
  description = "The ids of the subnets for the workload pods."
}

variable "aks_enable_disk_encryption" {
  type        = bool
  description = "Enable disk encryption with CMK for the AKS cluster."
  default     = false
}

variable "aks_vnet_id" {
  type        = string
  description = "The id of the vnet where the aks subnets are in."
}

variable "aks_run_command_enabled" {
  type        = bool
  description = "Enable run command for the AKS cluster."
  default     = false
}

variable "aks_cost_analysis_enabled" {
  type        = bool
  description = "Enable cost analysis for the AKS cluster."
  default     = true
}

variable "monitor_metrics" {
  type = object({
    annotations_allowed = optional(string, null)
    labels_allowed      = optional(string, null)
  })
  description = "Enable Azure Monitor Managed Prometheus"
  default     = null
}

variable "aks_diagnostic_log_categories" {
  description = "AKS diagnostic log configuration. Configure either category_groups or individual categories. Defaults to the current allLogs and audit category groups."
  type = object({
    category_groups = optional(list(string), [])
    categories      = optional(list(string), [])
  })

  default = {
    category_groups = ["allLogs", "audit"]
    categories      = []
  }

  validation {
    condition = (
      (length(var.aks_diagnostic_log_categories.category_groups) > 0) !=
      (length(var.aks_diagnostic_log_categories.categories) > 0)
    )
    error_message = "Configure either category_groups or categories for AKS diagnostic logging, but not both."
  }
}

variable "aks_support_plan" {
  description = "The support plan for the AKS cluster"
  type        = string
  default     = "KubernetesOfficial"
}

variable "web_app_routing" {
  description = "Enable web app routing for the AKS cluster"
  type = object({
    dns_zone_ids             = optional(list(string), [])
    default_nginx_controller = optional(string, "AnnotationControlled")
  })
  default = null
}
